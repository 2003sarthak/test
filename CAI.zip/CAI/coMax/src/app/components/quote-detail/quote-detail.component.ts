import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';

@Component({
  standalone: true,
  imports: [CommonModule],
  selector: 'app-quote-detail',
  templateUrl: './quote-detail.component.html',
  styleUrls: ['./quote-detail.component.css'],
})
export class QuoteDetailComponent {
  user = 'John Broker';
  quote = {
    id: 'QT-2025-001',
    generatedOn: 'March 15, 2025',
    premiumSummary: 4280,
    coverageLimit: 2000000,
    status: 'Active',
    renewalDate: 'March 15, 2026',
    insured: {
      name: 'John Smith Logistics',
      email: 'john@smithlogistics.com',
      businessType: 'Transportation & Logistics',
      yearsInBusiness: 8,
    },
    vehicle: {
      type: 'Commercial Truck',
      make: 'Freightliner Cascadia',
      year: 2023,
      vin: '1HGCM82633A123456',
    },
    coverage: {
      liability: 2000000,
      propertyDamage: 500000,
      deductible: 1000,
      medicalPayments: 10000,
    },
    premiumBreakdown: {
      basePremium: 3500,
      addOns: 580,
      taxes: 200,
      total: 4280,
    },
    endorsements: [
      {
        title: 'Roadside Assistance',
        description: '24/7 emergency roadside support',
      },
      {
        title: 'Rental Reimbursement',
        description: 'Up to $100/day for 30 days',
      },
      {
        title: 'Zero Depreciation',
        description: 'Full claim without depreciation',
      },
    ],
  };
}
