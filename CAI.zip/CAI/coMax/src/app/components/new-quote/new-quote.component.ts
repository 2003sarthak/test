import { Component } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-new-quote',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './new-quote.component.html',
  styleUrls: ['./new-quote.component.css'],
})
export class NewQuoteComponent {
  quoteForm: FormGroup;

  constructor(private fb: FormBuilder) {
    this.quoteForm = this.fb.group({
      // General Information
      quoteNumber: [''],
      effectiveDate: [''],
      expirationDate: [''],
      contactPhone: [''],
      brokerName: [''],
      brokerCode: [''],
      insuredName: [''],
      contactEmail: [''],
      insuredAddress: [''],

      // Vehicle Details
      vehicleType: [''],
      vehicleModel: [''],
      manufactureYear: [''],
      vin: [''],
      usageType: [''],
      annualMileage: [''],

      // Coverage & Premium Details
      deductibleAmount: ['0.00'],
      coverageLimit: [''],
      roadsideAssistance: [false],
      rentalReimbursement: [false],
      estimatedPremium: ['1250.00'],

      // Add-ons & Accessories
      addOnIMT23: [false],
      addOnZeroDepreciation: [false],
      electricalAccessoryValue: ['0.00'],
      nonElectricalAccessoryValue: ['0.00'],
      paCoverOwner: [false],
      paCoverPaid: [false],

      // Underwriting Questions
      priorClaims: ['No'],
      businessBankruptcy: ['No'],
      additionalInsureds: ['No'],
    });
  }

  onSubmit(): void {
    console.log('Form Data: ', this.quoteForm.value);
  }
}
