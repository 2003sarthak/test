import { Component } from '@angular/core';
import { CommonModule, CurrencyPipe, NgClass, NgFor } from '@angular/common';

@Component({
  selector: 'app-all-quotes',
  standalone: true,
  templateUrl: './all-quotes.component.html',
  styleUrls: ['./all-quotes.component.css'],
  imports: [NgFor, NgClass, CurrencyPipe, CommonModule],
})
export class AllQuotesComponent {
  quotes = [
    {
      id: '#QT-2025-001',
      client: 'Robert Wilson',
      company: 'ABC Logistics',
      vehicleType: 'Semi-Truck Fleet',
      createdDate: 'Jan 15, 2025',
      premium: 12450,
      status: 'Pending',
    },
    {
      id: '#QT-2025-002',
      client: 'Sophia Clark',
      company: 'TransCargo',
      vehicleType: 'Delivery Vans',
      createdDate: 'Feb 5, 2025',
      premium: 8500,
      status: 'Approved',
    },
    {
      id: '#QT-2025-003',
      client: 'David Johnson',
      company: 'Heavy Haulers Inc.',
      vehicleType: 'Heavy Trucks',
      createdDate: 'Mar 1, 2025',
      premium: 15200,
      status: 'Rejected',
    },
    {
      id: '#QT-2025-004',
      client: 'Emma Davis',
      company: 'Fleet Movers',
      vehicleType: 'Light Trucks',
      createdDate: 'Mar 12, 2025',
      premium: 9500,
      status: 'Pending',
    },
  ];

  getStatusClass(status: string) {
    switch (status) {
      case 'Pending':
        return 'pending';
      case 'Approved':
        return 'approved';
      case 'Rejected':
        return 'rejected';
      default:
        return '';
    }
  }
}
