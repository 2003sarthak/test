import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
@Component({
  selector: 'app-landing',
  imports: [
    RouterModule,
    CommonModule,
  ],
  templateUrl: './landing.component.html',
  styleUrl: './landing.component.css',
  standalone:true,
})
export class LandingComponent {
  dashboardImage = '../assets/dashboard.png';
}
