
import { Component, AfterViewInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import Chart from 'chart.js/auto';

@Component({
  standalone: true,
  imports: [CommonModule, RouterModule],
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css'],
})
export class DashboardComponent implements AfterViewInit {
  user = 'John Broker';
  stats = [
    { label: 'Total Quotes', value: 247, icon: 'fa-file-alt', change: '+12.5%', isPositive: true },
    { label: 'Active Policies', value: 182, icon: 'fa-check-circle', change: '+8.2%', isPositive: true },
  ];

  quotes = [
    { id: '#QT-2025-004', client: 'Robert Chen', vehicle: 'Heavy Truck', premium: '$2,450.00', status: 'Pending', created: '2 hours ago' },
    { id: '#QT-2025-003', client: 'Sarah Miller', vehicle: 'Fleet - 5 Units', premium: '$8,750.00', status: 'In Review', created: '1 day ago' },
    { id: '#QT-2025-002', client: 'Michael Brown', vehicle: 'Box Truck', premium: '$1,850.00', status: 'Approved', created: '2 days ago' },
  ];

  activities = [
    {
      icon: 'fa-check',
      message: 'Quote #12345 approved successfully.',
      quoteId: '12345',
      time: '5 mins ago',
    },
    {
      icon: 'fa-clock',
      message: 'Quote #12346 pending for review.',
      quoteId: '12346',
      time: '20 mins ago',
    },
    {
      icon: 'fa-times',
      message: 'Quote #12347 was rejected.',
      quoteId: '12347',
      time: '1 hour ago',
    },
    {
      icon: 'fa-info-circle',
      message: 'Quote #12348 needs additional info.',
      quoteId: '12348',
      time: '2 hours ago',
    },
  ];

  ngAfterViewInit() {
    new Chart('quoteChart', {
      type: 'doughnut',
      data: {
        labels: ['Active', 'Pending', 'Rejected'],
        datasets: [{ data: [182, 35, 30], backgroundColor: ['#4c8bf5', 'orange', 'red'] }],
      },
    });
  }
}
