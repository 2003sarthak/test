import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { FormsModule } from '@angular/forms';

@Component({
  standalone: true,
  selector: 'app-contact-us',
  templateUrl: './contact-us.component.html',
  styleUrls: ['./contact-us.component.css'],
  imports: [CommonModule, RouterModule, FormsModule],
})
export class ContactUsComponent {
  formData = {
    firstName: '',
    lastName: '',
    email: '',
    subject: 'Get a Quote',
    message: '',
  };

  submitForm() {
    console.log('Form submitted:', this.formData);
    alert('Your message has been sent!');
  }
}
