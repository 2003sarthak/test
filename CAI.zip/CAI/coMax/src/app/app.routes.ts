import { Routes } from '@angular/router';
import { LandingComponent } from './components/landing/landing.component';
import { LoginComponent } from './components/login/login.component';
import { SignupComponent } from './components/signup/signup.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { AllQuotesComponent } from './components/all-quotes/all-quotes.component';
import { AboutUsComponent } from './components/about-us/about-us.component';
import { ContactUsComponent } from './components/contact-us/contact-us.component';
import { NewQuoteComponent } from './components/new-quote/new-quote.component';
import { QuoteDetailComponent } from './components/quote-detail/quote-detail.component';

export const routes: Routes = [
  { path: '', component: LandingComponent },
  { path: 'login', component: LoginComponent },
  { path: 'signup', component: SignupComponent },
  {path: 'dashboard', component: DashboardComponent},
  {path: 'new-quote', component: NewQuoteComponent},
  {path: 'quotelist', component: AllQuotesComponent},
  {path: 'quotedetail', component: QuoteDetailComponent},
  {path:'about-us', component: AboutUsComponent},
  {path:'contact', component: ContactUsComponent},
  { path: '**', redirectTo: '' },
];
