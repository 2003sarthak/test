import { Component } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { User } from '../../Models/User.Model';
import { AbstractControl, FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, ValidationErrors, Validators } from '@angular/forms';
import { AlertComponent } from '../alert/alert.component';
import { CommonModule, NgIf } from '@angular/common';
import { UserServiceService } from '../../../Services/User.Service/user-service.service';

@Component({
  selector: 'app-signup',
  imports: [RouterLink,FormsModule,AlertComponent,ReactiveFormsModule,NgIf,CommonModule],
  templateUrl: './signup.component.html',
  styleUrl: './signup.component.css',
  standalone:true,
})
export class SignupComponent {
  signupForm: FormGroup;
  alertMessage: string | null = null;
  alertType: 'success' | 'error' | null = null;

  constructor(
    private router: Router,
    private fb: FormBuilder,
    private userService: UserServiceService 
  ) {
    this.signupForm = this.fb.group({
      fullName: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6), this.passwordValidator]]
    });
  }

  passwordValidator(control: AbstractControl): ValidationErrors | null {
    const password = control.value;
    if (!password) {
      return null;
    }

    const hasNumber = /\d/.test(password);
    const hasUpperCase = /[A-Z]/.test(password);
    const hasSpecialCharacter = /[!@#$%^&*(),.?":{}|<>]/.test(password);

    const valid = hasNumber && hasUpperCase && hasSpecialCharacter;
    if (!valid) {
      return { passwordStrength: true };
    }
    return null;
  }

  onSignup(): void {
    if (this.signupForm.valid) {
      const user: User = this.signupForm.value; // Use the User model
      
      // Call the backend register method
      this.userService.addUser(user).then((newUser) => {
        // Registration successful
        this.alertMessage = 'Signup successful!';
        this.alertType = 'success';
        this.router.navigate(['/home']); // Redirect to the home page
      }).catch((error) => {
        // Handle registration error
        if (error?.error?.message === 'A user with this email already exists.') {
          this.alertMessage = 'A user with this email already exists. Please use a different email.';
          this.alertType = 'error';
        } else {
          this.alertMessage = 'An error occurred during signup. Please try again.';
          this.alertType = 'error';
        }
      });
    } else {
      this.alertMessage = 'Please correct the errors in the form.';
      this.alertType = 'error';
      this.markAllAsTouched();
    }
  }
   
  // onSignup(): void {
  //   if (this.signupForm.valid) {
  //     const user: User = this.signupForm.value; // Use the User model
  //     const existingUser = this.userService.getUser(user.email, user.password);

  //     if (existingUser) {
  //       // If a user with the same email already exists, show an error message
  //       this.alertMessage = 'A user with this email already exists. Please use a different email.';
  //       this.alertType = 'error';
  //     } else {
  //       // Add the new user to the service
  //       this.userService.addUser(user);
  //       this.alertMessage = 'Signup successful!';
  //       this.alertType = 'success';
  //       this.router.navigate(['/home']);
  //     }
  //   } else {
  //     this.alertMessage = 'Please correct the errors in the form.';
  //     this.alertType = 'error';
  //     this.markAllAsTouched();
  //   }
  // }

  hasError(controlName: string, errorName: string): boolean {
    const control = this.signupForm.get(controlName);
    return control ? control.hasError(errorName) && control.touched : false;
  }

  private markAllAsTouched(): void {
    Object.keys(this.signupForm.controls).forEach(controlName => {
      this.signupForm.get(controlName)?.markAsTouched();
    });
  }
}
