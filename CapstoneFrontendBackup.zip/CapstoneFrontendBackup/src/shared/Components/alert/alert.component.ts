import { CommonModule } from '@angular/common';
import { Component, Input, SimpleChanges } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AlertServiceService } from '../../../Services/Alert.Service/alert-service.service';

@Component({
  selector: 'app-alert',
  imports: [FormsModule,CommonModule,ReactiveFormsModule],
  templateUrl: './alert.component.html',
  styleUrl: './alert.component.css'
})
export class AlertComponent {
  @Input() message: string | null = '';
  @Input() type: 'success' | 'error' | null = 'success';
  visible: boolean = true;

  constructor(private alertService: AlertServiceService) {}

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['message'] && changes['message'].currentValue) {
      this.visible = true;

      const newAlert = { 
        message: this.message, 
        type: this.type, 
        timestamp: new Date().getTime(),
        seen: false
      };

      this.alertService.addAlert(newAlert);

      setTimeout(() => {
        this.visible = false;
      }, 5000);
    }
  }
}





