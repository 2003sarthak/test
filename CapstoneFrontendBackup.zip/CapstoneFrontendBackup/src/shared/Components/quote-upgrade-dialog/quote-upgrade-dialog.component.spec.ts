import { ComponentFixture, TestBed } from '@angular/core/testing';

import { QuoteUpgradeDialogComponent } from './quote-upgrade-dialog.component';

describe('QuoteUpgradeDialogComponent', () => {
  let component: QuoteUpgradeDialogComponent;
  let fixture: ComponentFixture<QuoteUpgradeDialogComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [QuoteUpgradeDialogComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(QuoteUpgradeDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
