import { NgFor, NgIf } from '@angular/common';
import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'app-quote-upgrade-dialog',
  imports: [NgFor,NgIf],
  templateUrl: './quote-upgrade-dialog.component.html',
  styleUrl: './quote-upgrade-dialog.component.css'
})
export class QuoteUpgradeDialogComponent {
  @Input() selectedPlan: string|null|undefined= 'Normal';
  @Input() normalQuotedAmount: number|null = 0;
  @Input() goldQuotedAmount: number|null = 0;
  @Input() premiumQuotedAmount: number|null = 0;
  @Output() close = new EventEmitter<void>();
  get normalQuotedValue() {
    return this.normalQuotedAmount || 0;
  }

  get goldQuotedValue() {
    return this.goldQuotedAmount || 0;
  }

  get premiumQuotedValue() {
    return this.premiumQuotedAmount || 0;
  }

  get upgradeSuggestion() {
    if (this.selectedPlan === 'Normal') {
      return {
        upgradeTo: 'Gold',
        extraCost: this.goldQuotedValue - this.normalQuotedValue,
        claimIncreaseNote: 'Get up to 80% coverage instead of 60%',
        benefits: ['Accidental Losses', 'Minor Damage Coverage']
      };
    } else if (this.selectedPlan === 'Gold') {
      return {
        upgradeTo: 'Premium',
        extraCost: this.premiumQuotedValue - this.goldQuotedValue,
        claimIncreaseNote: 'Get up to 100% coverage instead of 80%',
        benefits: ['Business Interruption']
      };
    }
    return null;
  }

  closeDialog() {
    this.close.emit();
  }
}




