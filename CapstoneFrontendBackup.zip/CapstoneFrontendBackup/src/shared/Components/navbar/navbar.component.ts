import { Component } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { UserServiceService } from '../../../Services/User.Service/user-service.service';
import { User } from '../../Models/User.Model';
import { NgIf } from '@angular/common';

@Component({
  selector: 'app-navbar',
  imports: [RouterLink, NgIf],
  templateUrl: './navbar.component.html',
  styleUrl: './navbar.component.css'
})
export class NavbarComponent {
  showDropdown = false;
  loggedInUser: User | null = null;

  constructor(private userService: UserServiceService, private router: Router) {}

  ngOnInit(): void {
    this.loggedInUser = this.userService.getLoggedInUser();
    this.userService.userLoggedIn$.subscribe(user => {
      this.loggedInUser = user;
    });
  }

  logout(): void {
    this.userService.logout();
    this.loggedInUser = null;
    this.router.navigate(['/home']);
  }
}
