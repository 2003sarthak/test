import { Component } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { UserServiceService } from '../../../Services/User.Service/user-service.service';
import { User } from '../../Models/User.Model';
import { CommonModule, NgFor, NgIf } from '@angular/common';
import { AlertServiceService } from '../../../Services/Alert.Service/alert-service.service';

@Component({
  selector: 'app-navbar',
  imports: [RouterLink, NgIf,NgFor,CommonModule],
  templateUrl: './navbar.component.html',
  styleUrl: './navbar.component.css'
})
export class NavbarComponent {
  showDropdown = false;
  loggedInUser: User | null = null;
  alerts: any[] = [];
  showNotifications: boolean = false;

  constructor(private userService: UserServiceService, private alertService: AlertServiceService, private router: Router) {}

  ngOnInit(): void {
    this.loggedInUser = this.userService.getLoggedInUser();
    this.userService.userLoggedIn$.subscribe(user => {
      this.loggedInUser = user;
    });

    // Subscribe to alerts dynamically
    this.alertService.alerts$.subscribe(alerts => {
      this.alerts = alerts;
    });
  }

  get allAlerts() {
    return this.alerts;
  }

  toggleNotifications(): void {
    this.showNotifications = !this.showNotifications;
  }

  markAsRead(index: number): void {
    this.alertService.markAlertAsRead(index);
  }

  get unreadCount(): number {
    return this.alerts.filter(alert => !alert.seen).length;
  }

  logout(): void {
    this.userService.logout();
    this.loggedInUser = null;
    this.router.navigate(['/home']).then(() => {
      window.scrollTo(0, 0);
    });
  }
}





