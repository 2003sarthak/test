import { Component } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { AlertComponent } from '../alert/alert.component';
import { CommonModule, NgIf } from '@angular/common';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { UserServiceService } from '../../../Services/User.Service/user-service.service';

@Component({
  selector: 'app-login',
  imports: [RouterLink,AlertComponent,NgIf,FormsModule,ReactiveFormsModule,CommonModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css',
  standalone:true,
})
export class LoginComponent {
  loginForm: FormGroup;
  alertMessage: string | null = null;
  alertType: 'success' | 'error' | null = null;

  constructor(
    private fb: FormBuilder,
    private userService: UserServiceService,
    private router: Router
  ) {
    this.loginForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]]
    });
  }

  onLogin(): void {
    if (this.loginForm.valid) {
      const email = this.loginForm.get('email')?.value;
      const password = this.loginForm.get('password')?.value;
  
      // Call the backend login method
      this.userService.getUser(email, password).then((user) => {
        if (user) {
          this.userService.setLoggedInUser(user); // Save the logged-in user
          this.alertMessage = 'Login successful! Welcome back.';
          this.alertType = 'success';
          console.log('Logged-in User:', user);
          this.router.navigate(['/home']); // Redirect to the home page
        } else {
          this.alertMessage = 'Invalid email or password. Please try again.';
          this.alertType = 'error';
        }
      }).catch((error) => {
        // Handle login error
        this.alertMessage = 'An error occurred during login. Please try again.';
        this.alertType = 'error';
        console.error('Login error:', error);
      });
    } else {
      this.alertMessage = 'Please correct the errors in the form.';
      this.alertType = 'error';
      this.markAllAsTouched(); // Highlight invalid fields
    }
  }

  // onLogin(): void {
  //   if (this.loginForm.valid) {
  //     const email = this.loginForm.get('email')?.value;
  //     const password = this.loginForm.get('password')?.value;

  //     const user = this.userService.getUser(email, password);

  //     if (user) {
  //       this.userService.setLoggedInUser(user);
  //       this.alertMessage = 'Login successful! Welcome back.';
  //       this.alertType = 'success';
  //       console.log('Logged-in User:', user);
  //       this.router.navigate(['/home']);
  //     } else {
  //       this.alertMessage = 'Invalid email or password. Please try again.';
  //       this.alertType = 'error';
  //     }
  //   } else {
  //     this.alertMessage = 'Please correct the errors in the form.';
  //     this.alertType = 'error';
  //     this.markAllAsTouched();
  //   }
  // }

  hasError(controlName: string, errorName: string): boolean {
    const control = this.loginForm.get(controlName);
    return control ? control.hasError(errorName) && control.touched : false;
  }

  private markAllAsTouched(): void {
    Object.keys(this.loginForm.controls).forEach(controlName => {
      this.loginForm.get(controlName)?.markAsTouched();
    });
  }
}
