export interface Quote {
  id?: number;
  brokerName: string;
  brokerId: string;
  businessName: string;
  gstNo:string;
  annualTurnover: number;
  propertyValue: number;
  ownershipType: string;
  businessType: string;
  locationType: string;
  securitySystem: string;
  previousClaims: string;
  securityMeasures: boolean;
  planType: 'Normal' | 'Gold' | 'Premium';
  quoteAmount: number;
  status: boolean;
  created: Date;
}
