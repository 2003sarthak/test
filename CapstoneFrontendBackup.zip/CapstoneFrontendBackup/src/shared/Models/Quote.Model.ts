export interface Quote {
  id?: number;
  brokerName: string;
  brokerId: string;
  businessName: string;
  gstNo:string;
  annualTurnover: number;
  propertyValue: number;
  ownershipType: string;
  businessType: string;
  locationType: string;
  securitySystem: string;
  previousClaims: string;
  securityMeasures: boolean;
  planType: 'Normal' | 'Gold' | 'Premium';
  quoteAmount: number;
  status: boolean;
  created: Date;

  //additional Information about busiess
  businessAddress: string; 
  contactPersonName:string; 
  contactPhoneNumber:string; 
  email:string; 
  yearOfOperation:number ;
  numberOfEmployees:number ;
  naturalCalamityCoverageNeeded:boolean ;
  aboutBusiness:string; 
}



