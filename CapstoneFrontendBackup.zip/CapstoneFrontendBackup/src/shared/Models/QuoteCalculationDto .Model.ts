export class QuoteCalculationDto {
  annualTurnover: number;
  propertyValue: number;
  ownershipType: string; // Expected values: "Owned" or "Rented"
  businessType: string;  // Expected values: "Retail", "Manufacturing", "High Risk", etc.
  locationType: string;  // Expected values: "Urban", "Semiurban", "Rural", etc.
  planType: string;      // Expected values: "Gold", "Premium", etc.
  yearOfOperation: number; 
  numberOfEmployees: number; 
  naturalCalamityCoverageNeeded: boolean; // Expected values: true or false

  constructor(
    annualTurnover: number,
    propertyValue: number,
    ownershipType: string,
    businessType: string,
    locationType: string,
    planType: string,
    yearOfOperation: number,
    numberOfEmployees: number,
    naturalCalamityCoverageNeeded: boolean
  ) {
    this.annualTurnover = annualTurnover;
    this.propertyValue = propertyValue;
    this.ownershipType = ownershipType;
    this.businessType = businessType;
    this.locationType = locationType;
    this.planType = planType;
    this.yearOfOperation = yearOfOperation;
    this.numberOfEmployees = numberOfEmployees;
    this.naturalCalamityCoverageNeeded = naturalCalamityCoverageNeeded;
  }
}