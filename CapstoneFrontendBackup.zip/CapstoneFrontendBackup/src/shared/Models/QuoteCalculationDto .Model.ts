export class QuoteCalculationDto {
    annualTurnover: number;
    propertyValue: number;
    ownershipType: string; // Expected values: "Owned" or "Rented"
    businessType: string;  // Expected values: "Retail", "Manufacturing", "High Risk", etc.
    locationType: string;  // Expected values: "Urban", "Semiurban", "Rural", etc.
    planType: string;      // Expected values: "Gold", "Premium", etc.
  
    constructor(
      annualTurnover: number,
      propertyValue: number,
      ownershipType: string,
      businessType: string,
      locationType: string,
      planType: string
    ) {
      this.annualTurnover = annualTurnover;
      this.propertyValue = propertyValue;
      this.ownershipType = ownershipType;
      this.businessType = businessType;
      this.locationType = locationType;
      this.planType = planType;
    }
  }