import { Component, OnInit } from '@angular/core';
import { NavigationEnd, Router, RouterOutlet } from '@angular/router';
import { NavbarComponent } from '../shared/Components/navbar/navbar.component';
import { FooterComponent } from '../shared/Components/footer/footer.component';
import { UserServiceService } from '../Services/User.Service/user-service.service';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet,NavbarComponent,FooterComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent implements OnInit {
  title = 'BizProtect';

  constructor(private userService: UserServiceService,private router: Router) {}

  ngOnInit() {
    this.router.events.subscribe(event => {
      if (event instanceof NavigationEnd) {
        window.scrollTo(0, 0); 
      }
    });
  }

  isLoggedIn(): boolean {
    return this.userService.getLoggedInUser() !== null;
  }
}


