import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { NavbarComponent } from '../shared/Components/navbar/navbar.component';
import { FooterComponent } from '../shared/Components/footer/footer.component';
import { UserServiceService } from '../Services/User.Service/user-service.service';
import { NgIf } from '@angular/common';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet,NavbarComponent,FooterComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'BizProtect';

  constructor(private userService: UserServiceService) {}

  isLoggedIn(): boolean {
    return this.userService.getLoggedInUser() !== null;
  }
}
