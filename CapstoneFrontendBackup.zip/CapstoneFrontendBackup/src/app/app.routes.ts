import { Routes } from '@angular/router';
import { HomeComponent } from '../Pages/home/home.component';
import { AboutComponent } from '../Pages/about/about.component';
import { QuoteComponent } from '../Pages/quote/quote.component';
import { DashboardComponent } from '../Pages/dashboard/dashboard.component';
import { ContactComponent } from '../Pages/contact/contact.component';
import { LoginComponent } from '../shared/Components/login/login.component';
import { SignupComponent } from '../shared/Components/signup/signup.component';
import { QuoteDetailsComponent } from '../Pages/quote-details/quote-details.component';
import { QuoteEditComponent } from '../Pages/quote-edit/quote-edit.component';
import { TermsAndConditionComponent } from '../Pages/terms-and-condition/terms-and-condition.component';
import { QuoteListComponent } from '../Pages/quote-list/quote-list.component';

export const routes: Routes = [
  { path: '', redirectTo: '/home', pathMatch: 'full' },
  { path: 'home', component: HomeComponent },
  { path: 'dashboard', component: DashboardComponent },
  { path: 'quote', component: QuoteComponent },
  { path: 'quotelist', component: QuoteListComponent },
  { path: 'quotedetails/:id', component: QuoteDetailsComponent },
  { path: 'quoteedit/:id', component: QuoteEditComponent },
  { path: 'about', component: AboutComponent },
  { path: 'contacts', component: ContactComponent },
  { path: 'login', component: LoginComponent },
  { path: 'signup', component: SignupComponent },
  { path: 'term-and-condition', component: TermsAndConditionComponent },
];
