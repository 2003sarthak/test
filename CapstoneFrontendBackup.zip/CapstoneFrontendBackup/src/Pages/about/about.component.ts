import { NgFor } from '@angular/common';
import { Component } from '@angular/core';

@Component({
  selector: 'app-about',
  imports: [NgFor],
  templateUrl: './about.component.html',
  styleUrl: './about.component.css'
})
export class AboutComponent {
  teamMembers = [
    {
      photo: 'mukund.jpg',
      name: 'Mukund Bajpai',
      designation: 'Innovation Team Head',
      description: 'Mukund Bajpai is the Innovation Team Head of the company. Graduated from HBTU, he is responsible for bringing innovation in work and for the company.'
    },
    {
      photo: 'harsh.png',
      name: 'Harsh Upadhaya',
      designation: 'Tech Lead',
      description: 'Harsh Upadhaya is the Technology Head of the company. Graduated from IET, he is responsible for bringing new technology and latest trends, overseeing the technological aspects of the company.'
    },
    {
      photo: 'pragya.jpg',
      name: 'Pragya Singh',
      designation: 'Head HR',
      description: 'Pragya Singh is the Head HR of the company. Graduated from HBTU, she oversees the human resources department.'
    }
  ];

  counter = 0;
  size = 800; // Adjust based on your container width
  transformStyle = 'translateX(0px)';

  ngOnInit() {
    setInterval(() => {
      this.nextSlide();
    }, 5000);
  }

  nextSlide() {
    if (this.counter >= this.teamMembers.length - 1) {
      this.counter = -1;
    }
    this.counter++;
    this.updateTransformStyle();
  }

  prevSlide() {
    if (this.counter <= 0) {
      this.counter = this.teamMembers.length;
    }
    this.counter--;
    this.updateTransformStyle();
  }

  updateTransformStyle() {
    this.transformStyle = `translateX(${-this.size * this.counter}px)`;
  }
}


