import { CommonModule, NgIf } from '@angular/common';
import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Quote } from '../../shared/Models/Quote.Model';
import { QuoteService } from '../../Services/Quote.Service/quote.service';
import { RatingService } from '../../Services/Rating.Service/rating.service';
import { AlertComponent } from '../../shared/Components/alert/alert.component';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';

@Component({
  selector: 'app-quote-details',
  imports: [NgIf,CommonModule,AlertComponent],
  templateUrl: './quote-details.component.html',
  styleUrl: './quote-details.component.css'
})

export class QuoteDetailsComponent {
  quoteDetails: Quote | null = null;
  alertMessage: string | null = null;
  alertType: 'success' | 'error' | null = null;

  baseRate: number | null = null;
  businessTypeRate: number | null = null;
  locationRate: number | null = null;
  propertyRate: number | null = null;
  turnoverComponent: number | null = null;
  finalRate: number | null = null;
  quoteAmount: number | null = null;
  experienceRate: number | null = null;
  employeeRate: number | null = null;
  calamityCoverageRate: number | null = null;

  constructor(
    private route: ActivatedRoute,
    private quoteService: QuoteService,
    private ratingService: RatingService
  ) {}

  ngOnInit() {
    const id = Number(this.route.snapshot.paramMap.get('id')); // Get the quote ID from the route
    if (isNaN(id) || id <= 0) {
      this.alertMessage = 'Invalid Quote ID provided!';
      this.alertType = 'error';
      return;
    }
    this.getQuoteDetails(id);
  }

  getQuoteDetails(id: number) {
    // Fetch the quote details by ID
    this.quoteService.getQuoteById(id).subscribe({
      next: (quote) => {
        if (quote) {
          this.quoteDetails = quote;
          this.calculateQuote(quote); // Calculate the quote dynamically using the rating API
        } else {
          this.alertMessage = 'Quote not found!';
          this.alertType = 'error';
        }
      },
      error: (err) => {
        console.error('Error fetching quote details:', err);
        this.alertMessage = 'Quote not found!';
        this.alertType = 'error';
      }
    });
  }

  calculateQuote(quote: Quote) {
    // Prepare the DTO for the Rating API, including the newly added fields
    const quoteDto = {
      annualTurnover: quote.annualTurnover,
      propertyValue: quote.propertyValue,
      ownershipType: quote.ownershipType,
      businessType: quote.businessType,
      locationType: quote.locationType,
      planType: quote.planType,
      yearOfOperation: quote.yearOfOperation,  
      numberOfEmployees: quote.numberOfEmployees, 
      naturalCalamityCoverageNeeded: quote.naturalCalamityCoverageNeeded 
    };
  
    // Call the RatingService to calculate the breakdown
    this.ratingService.calculateQuote(quoteDto).subscribe({
      next: (calculated) => {
        this.baseRate = calculated.breakdown.baseRate;
        this.businessTypeRate = calculated.breakdown.businessTypeRate;
        this.locationRate = calculated.breakdown.locationRate;
        this.propertyRate = calculated.breakdown.propertyRate;
        this.turnoverComponent = calculated.breakdown.turnoverComponent;
        this.finalRate = calculated.breakdown.finalRate;
        this.quoteAmount = calculated.quoteAmount;
        this.experienceRate = calculated.breakdown.experienceRate;
        this.employeeRate = calculated.breakdown.employeeRate;
        this.calamityCoverageRate = calculated.breakdown.calamityCoverageRate;
  
        this.alertMessage = 'Quote calculated successfully!';
        this.alertType = 'success';
      },
      error: (err) => {
        console.error('Error calculating quote:', err);
        this.alertMessage = 'Error calculating quote values!';
        this.alertType = 'error';
      }
    });
  }

  downloadQuotePDF() {
    if (!this.quoteDetails) {
      this.alertMessage = 'Quote details are not available to download!';
      this.alertType = 'error';
      return;
    }
  
    const doc = new jsPDF();
  
    const fontSize = 12;
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(fontSize);
    const imgData = 'logofinal1.png';
    // Function to add watermark & header on each page
    const addPageElements = (doc: jsPDF) => {
      const pageCount = doc.getNumberOfPages();
        for (let i = 1; i <= pageCount; i++) {
            doc.setPage(i); // Set active page
            // Add watermark at center
            doc.addImage(imgData, 'PNG', 40, 80, 120, 140,);
        }
    };
    doc.setTextColor(255, 215, 0);
    doc.setFontSize(24);
    doc.text('BizProtect', 14, 20); // Title at top of the page
    doc.setTextColor(0, 0, 0);
  
    // Add Quote Details Title below the header
    doc.setFontSize(16);
    doc.text('Quote Details', 14, 40);

    addPageElements(doc);
  
    // Start Adding Quote Details
    const details = [
      { label: 'Broker ID', value: this.quoteDetails.brokerId },
      { label: 'Broker Name', value: this.quoteDetails.brokerName },
      { label: 'Business Name', value: this.quoteDetails.businessName },
      { label: 'GST Number', value: this.quoteDetails.gstNo },
      { label: 'Annual Turnover', value: `Rs. ${this.quoteDetails.annualTurnover}` },
      { label: 'Property Value', value: `Rs. ${this.quoteDetails.propertyValue}` },
      { label: 'Location Type', value: this.quoteDetails.locationType },
      { label: 'Contact Person', value: this.quoteDetails.contactPersonName },
      { label: 'Phone Number', value: this.quoteDetails.contactPhoneNumber },
      { label: 'Email', value: this.quoteDetails.email },
      { label: 'Business Address', value: this.quoteDetails.businessAddress },
      { label: 'Year of Operation', value: this.quoteDetails.yearOfOperation },
      { label: 'Number of Employees', value: this.quoteDetails.numberOfEmployees },
      { label: 'Security Systems', value: this.quoteDetails.securitySystem },
      { label: 'Previous Claims', value: this.quoteDetails.previousClaims },
      { label: 'Natural Calamity Coverage Needed', value: this.quoteDetails.naturalCalamityCoverageNeeded ? 'Yes' : 'No' },
      { label: 'About Business', value: this.quoteDetails.aboutBusiness },
      { label: 'Plan Type', value: this.quoteDetails.planType },
      { label: 'Quote Amount', value: `Rs. ${this.quoteDetails.quoteAmount}` },
      { label: 'Status', value: this.quoteDetails.status ? 'Submitted' : 'Draft' },
    ];
  
    details.forEach((detail, index) => {
      doc.text(`${detail.label}: ${detail.value}`, 14, 50 + index * 10);
    });
  
    // Add Breakdown Table if factors exist
    if (this.baseRate || this.businessTypeRate || this.locationRate || this.experienceRate || this.employeeRate || this.calamityCoverageRate) {
      const breakdownTable = [
        ['Property Value', `Rs. ${this.propertyRate || 0}`],
        ['Base Rate', `${(this.baseRate || 0) * 100}%`],
        ['Business Type Adjustment', `${(this.businessTypeRate || 0) * 100}%`],
        ['Location Adjustment', `${(this.locationRate || 0) * 100}%`],
        ['Years of Operation Adjustment', `${(this.experienceRate || 0) * 100}%`],
        ['Employee Count Adjustment', `${(this.employeeRate || 0) * 100}%`],
        ['Natural Calamity Coverage Adjustment', `${(this.calamityCoverageRate || 0) * 100}%`],
        ['Total Adjustment', `${(this.finalRate || 0) * 100}%`],
      ];
  
      autoTable(doc, {
        startY: 50 + details.length * 10,
        head: [['Factor', 'Percentage/Adjustment']],
        body: breakdownTable,
        styles: {
          font: 'helvetica',
          fontSize: fontSize,
        },
      });
    }
    
  
    doc.save(`quote-details-${this.quoteDetails.businessName}.pdf`);
  }
}





