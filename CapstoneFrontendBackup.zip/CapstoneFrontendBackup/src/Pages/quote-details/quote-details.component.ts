import { CommonModule, NgIf } from '@angular/common';
import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Quote } from '../../shared/Models/Quote.Model';
import { QuoteService } from '../../Services/Quote.Service/quote.service';
import { RatingService } from '../../Services/Rating.Service/rating.service';
import { AlertComponent } from '../../shared/Components/alert/alert.component';
import jsPDF from 'jspdf';
import autoTable from 'jspdf-autotable';

@Component({
  selector: 'app-quote-details',
  imports: [NgIf,CommonModule,AlertComponent],
  templateUrl: './quote-details.component.html',
  styleUrl: './quote-details.component.css'
})

export class QuoteDetailsComponent {
  quoteDetails: Quote | null = null;
  alertMessage: string | null = null;
  alertType: 'success' | 'error' | null = null;

  baseRate: number | null = null;
  businessTypeRate: number | null = null;
  locationRate: number | null = null;
  propertyRate: number | null = null;
  turnoverComponent: number | null = null;
  finalRate: number | null = null;
  quoteAmount: number | null = null;

  constructor(
    private route: ActivatedRoute,
    private quoteService: QuoteService,
    private ratingService: RatingService
  ) {}

  ngOnInit() {
    const id = Number(this.route.snapshot.paramMap.get('id')); // Get the quote ID from the route
    if (isNaN(id) || id <= 0) {
      this.alertMessage = 'Invalid Quote ID provided!';
      this.alertType = 'error';
      return;
    }
    this.getQuoteDetails(id);
  }

  getQuoteDetails(id: number) {
    // Fetch the quote details by ID
    this.quoteService.getQuoteById(id).subscribe({
      next: (quote) => {
        if (quote) {
          this.quoteDetails = quote;
          this.calculateQuote(quote); // Calculate the quote dynamically using the rating API
        } else {
          this.alertMessage = 'Quote not found!';
          this.alertType = 'error';
        }
      },
      error: (err) => {
        console.error('Error fetching quote details:', err);
        this.alertMessage = 'Quote not found!';
        this.alertType = 'error';
      }
    });
  }

  calculateQuote(quote: Quote) {
    // Prepare the DTO for the Rating API
    const quoteDto = {
      annualTurnover: quote.annualTurnover,
      propertyValue: quote.propertyValue,
      ownershipType: quote.ownershipType,
      businessType: quote.businessType,
      locationType: quote.locationType,
      planType: quote.planType,
    };

    // Call the RatingService to calculate the breakdown
    this.ratingService.calculateQuote(quoteDto).subscribe({
      next: (calculated) => {
        this.baseRate = calculated.breakdown.baseRate;
        this.businessTypeRate = calculated.breakdown.businessTypeRate;
        this.locationRate = calculated.breakdown.locationRate;
        this.propertyRate = calculated.breakdown.propertyRate;
        this.turnoverComponent = calculated.breakdown.turnoverComponent;
        this.finalRate = calculated.breakdown.finalRate;
        this.quoteAmount = calculated.quoteAmount;
      },
      error: (err) => {
        console.error('Error calculating quote:', err);
        this.alertMessage = 'Error calculating quote values!';
        this.alertType = 'error';
      }
    });
  }

  downloadQuotePDF() {
    if (!this.quoteDetails) {
      this.alertMessage = 'Quote details are not available to download!';
      this.alertType = 'error';
      return;
    }
  
    const doc = new jsPDF();
  
    const fontSize = 12; 
    doc.setFont('helvetica', 'normal'); 
    doc.setFontSize(fontSize);
  
    doc.setFontSize(16); 
    doc.text('Quote Details', 14, 20);
  
    doc.setFontSize(fontSize);
  
    const details = [
      { label: 'Broker ID', value: this.quoteDetails.brokerId },
      { label: 'Broker Name', value: this.quoteDetails.brokerName },
      { label: 'Business Name', value: this.quoteDetails.businessName },
      { label: 'GST Number', value: this.quoteDetails.gstNo },
      { label: 'Annual Turnover', value: `₹ ${this.quoteDetails.annualTurnover}` },
      { label: 'Property Value', value: `₹ ${this.quoteDetails.propertyValue}` },
      { label: 'Location Type', value: this.quoteDetails.locationType },
      { label: 'Plan Type', value: this.quoteDetails.planType },
      { label: 'Quote Amount', value: `₹ ${this.quoteDetails.quoteAmount}` },
      { label: 'Status', value: this.quoteDetails.status ? 'Submitted' : 'Draft' },
    ];
  
    details.forEach((detail, index) => {
      doc.text(`${detail.label}: ${detail.value}`, 14, 30 + index * 10);
    });
  
    if (this.baseRate || this.businessTypeRate || this.locationRate) {
      const breakdownTable = [
        ['Base Rate', `${(this.baseRate || 0) * 100}%`],
        ['Business Type Adjustment', `${(this.businessTypeRate || 0) * 100}%`],
        ['Location Adjustment', `${(this.locationRate || 0) * 100}%`],
        ['Property Value', `₹ ${this.propertyRate || 0}`],
        ['Total Adjustment', `${(this.finalRate || 0) * 100}%`],
      ];
  
      autoTable(doc, {
        startY: 30 + details.length * 10,
        head: [['Factor', 'Percentage/Adjustment']],
        body: breakdownTable,
        styles: {
          font: 'helvetica', 
          fontSize: fontSize,
        },
      });
    }
  
    doc.save(`quote-details-${this.quoteDetails.businessName}.pdf`);
  }

}



// export class QuoteDetailsComponent {
//   quoteDetails: any = null;
//   submittedQuotes: any[] = JSON.parse(localStorage.getItem('submittedQuotes') || '[]'); // Fetching from local storage
//   baseRate = 0.005;
//   businessTypeRate = 0;
//   propertyRate = 0;
//   locationRate = 0;
//   finalRate = 0;

//   constructor(private route: ActivatedRoute) {}

//   ngOnInit() {
//     const id = this.route.snapshot.paramMap.get('id'); // Get the quote ID from route
//     this.quoteDetails = this.submittedQuotes.find(quote => quote.id === id); // Find the quote by ID

//     if (this.quoteDetails) {
//       this.calculateRates();
//     }
//   }

//   calculateRates() {
//     // Plan type adjustment
//     switch (this.quoteDetails.planType) {
//       case 'Gold':
//         this.baseRate = 0.01;
//         break;
//       case 'Premium':
//         this.baseRate = 0.015;
//         break;
//     }

//     // Business type adjustment
//     switch (this.quoteDetails.businessType) {
//       case 'Retail':
//         this.businessTypeRate = 0.0025;
//         break;
//       case 'Manufacturing':
//         this.businessTypeRate = 0.005;
//         break;
//       case 'High Risk':
//         this.businessTypeRate = 0.0075;
//         break;
//     }

//     // Property value adjustment
//     let propertyPer = 0.0005; 
//     if (this.quoteDetails.ownershipType === 'Owned') {
//       propertyPer += 0.00025; 
//     } else if (this.quoteDetails.ownershipType === 'Rented') {
//       propertyPer -= 0.00025;
//     }
//     this.propertyRate = Number(this.quoteDetails.propertyValue) * propertyPer;

//     // Location type adjustment
//     switch (this.quoteDetails.locationType) {
//       case 'Urban':
//         this.locationRate = 0.0025;
//         break;
//       case 'Semiurban':
//         this.locationRate = 0.005;
//         break;
//       case 'Rural':
//         this.locationRate = 0.0075;
//         break;
//     }

//     // Calculate final rate
//     this.finalRate = this.baseRate + this.businessTypeRate + this.locationRate;
//   }
// }