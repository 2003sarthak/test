import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Quote } from '../../shared/Models/Quote.Model';
import { QuoteService } from '../../Services/Quote.Service/quote.service';
import { RatingService } from '../../Services/Rating.Service/rating.service';
import { AlertComponent } from '../../shared/Components/alert/alert.component';

@Component({
  selector: 'app-quote-edit',
  imports: [FormsModule,CommonModule,ReactiveFormsModule,AlertComponent],
  templateUrl: './quote-edit.component.html',
  styleUrl: './quote-edit.component.css'
})
// export class QuoteEditComponent {
//   quoteForm!: FormGroup;
//   quoteDetails: any = null;
//   submittedQuotes: any[] = JSON.parse(localStorage.getItem('submittedQuotes') || '[]'); 

//   constructor(private route: ActivatedRoute, private router: Router) {}

//   ngOnInit() {
//     const id = this.route.snapshot.paramMap.get('id');
//     this.quoteDetails = this.submittedQuotes.find(quote => quote.id === id);

//     if (this.quoteDetails) {
//       this.quoteForm = new FormGroup({
//         businessName: new FormControl(this.quoteDetails.businessName, Validators.required),
//         gstNo: new FormControl(this.quoteDetails.gstNo, [Validators.minLength(15),Validators.maxLength(15)]),
//         annualTurnover: new FormControl(this.quoteDetails.annualTurnover, [Validators.required, Validators.min(10000)]),
//         businessType: new FormControl(this.quoteDetails.businessType, Validators.required),
//         propertyValue: new FormControl(this.quoteDetails.propertyValue, Validators.required),
//         ownershipType: new FormControl(this.quoteDetails.ownershipType, Validators.required),
//         locationType: new FormControl(this.quoteDetails.locationType, Validators.required),
//         securitySystem: new FormControl(this.quoteDetails.securitySystem),
//         previousClaims: new FormControl(this.quoteDetails.previousClaims),
//         planType: new FormControl(this.quoteDetails.planType, Validators.required),
//         brokerName: new FormControl({ value: this.quoteDetails.brokerName, disabled: true }),
//         brokerId: new FormControl({ value: this.quoteDetails.brokerId, disabled: true }),
//       });
//     }
//   }

//   calculateQuote() {
//     let baseRate = 0.005;

//     // Plan type adjustment
//     switch (this.quoteForm.value.planType) {
//       case 'Gold':
//         baseRate = 0.01;
//         break;
//       case 'Premium':
//         baseRate = 0.015;
//         break;
//     }

//     // Business type adjustment
//     let businessTypeRate = 0;
//     switch (this.quoteForm.value.businessType) {
//       case 'Retail':
//         businessTypeRate = 0.0025;
//         break;
//       case 'Manufacturing':
//         businessTypeRate = 0.005;
//         break;
//       case 'High Risk':
//         businessTypeRate = 0.0075;
//         break;
//     }

//     // Property value adjustment
//     let propertyPer = 0.0005; 
//     if (this.quoteForm.value.ownershipType === 'Owned') {
//       propertyPer += 0.00025; 
//     } else if (this.quoteForm.value.ownershipType === 'Rented') {
//       propertyPer -= 0.00025;
//     }
//     const propertyRate = Number(this.quoteForm.value.propertyValue) * propertyPer;

//     // Location type adjustment
//     let locationRate = 0;
//     switch (this.quoteForm.value.locationType) {
//       case 'Urban':
//         locationRate = 0.0025;
//         break;
//       case 'Semiurban':
//         locationRate = 0.005;
//         break;
//       case 'Rural':
//         locationRate = 0.0075;
//         break;
//     }

//     // Calculate final rate
//     const finalRate = baseRate + businessTypeRate + locationRate;
//     const finalValue = Math.round(Number(this.quoteForm.value.annualTurnover) * finalRate);

//     // Calculate the quote
//     return finalValue + propertyRate;
//   }

//   saveChanges() {
//     if (this.quoteForm.valid) {
//       // Update local storage
//       const updatedQuote = { 
//         ...this.quoteDetails, 
//         ...this.quoteForm.value, 
//         quoteAmount: this.calculateQuote(), 
//         status: true 
//       };
//       const index = this.submittedQuotes.findIndex(quote => quote.id === this.quoteDetails.id);
//       this.submittedQuotes[index] = updatedQuote;
//       localStorage.setItem('submittedQuotes', JSON.stringify(this.submittedQuotes));

//       // Navigate back to the dashboard
//       this.router.navigate(['/dashboard']);
//     }
//   }
// }

export class QuoteEditComponent {
  quoteForm: FormGroup; // Initialize with all required controls
  quoteDetails: Quote | null = null;
  alertMessage: string | null = null;
  alertType: 'success' | 'error' | null = null;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private quoteService: QuoteService,
    private ratingService: RatingService
  ) {
    // Create the FormGroup with default values or empty controls
    this.quoteForm = new FormGroup({
      businessName: new FormControl('', Validators.required),
      gstNo: new FormControl('', [
        Validators.minLength(15),
        Validators.maxLength(15),
      ]),
      annualTurnover: new FormControl('', [
        Validators.required,
        Validators.min(10000),
      ]),
      businessType: new FormControl('', Validators.required),
      propertyValue: new FormControl('', Validators.required),
      ownershipType: new FormControl('', Validators.required),
      locationType: new FormControl('', Validators.required),
      securitySystem: new FormControl(''),
      previousClaims: new FormControl(''),
      planType: new FormControl('', Validators.required),
      brokerName: new FormControl({ value: '', disabled: true }), 
      brokerId: new FormControl({ value: '', disabled: true }), 
    });
  }

  ngOnInit() {
    const id = Number(this.route.snapshot.paramMap.get('id')); // Get the quote ID from the route
    if (isNaN(id) || id <= 0) {
      this.alertMessage = 'Invalid Quote ID provided!';
      this.alertType = 'error';
      return;
    }
    this.loadQuoteDetails(id);
  }

  loadQuoteDetails(id: number) {
    // Fetch the quote details by ID from the server
    this.quoteService.getQuoteById(id).subscribe({
      next: (quote) => {
        this.quoteDetails = quote;
        this.updateFormValues(quote);
      },
      error: (err) => {
        console.error('Error loading quote details:', err);
        this.alertMessage = 'Error loading quote details!';
        this.alertType = 'error';
      },
    });
  }

  updateFormValues(quote: Quote) {
    // Update the form controls with the actual quote data
    this.quoteForm.patchValue({
      businessName: quote.businessName,
      gstNo: quote.gstNo,
      annualTurnover: quote.annualTurnover,
      businessType: quote.businessType,
      propertyValue: quote.propertyValue,
      ownershipType: quote.ownershipType,
      locationType: quote.locationType,
      securitySystem: quote.securitySystem,
      previousClaims: quote.previousClaims,
      planType: quote.planType,
      brokerName: quote.brokerName,
      brokerId: quote.brokerId,
    });
  }

  saveChanges() {
    if (this.quoteForm.invalid) {
      this.alertMessage = 'Please complete all required fields!';
      this.alertType = 'error';
      return;
    }
  
    const updatedQuoteDto = {
      annualTurnover: this.quoteForm.value.annualTurnover,
      propertyValue: this.quoteForm.value.propertyValue,
      ownershipType: this.quoteForm.value.ownershipType,
      businessType: this.quoteForm.value.businessType,
      locationType: this.quoteForm.value.locationType,
      planType: this.quoteForm.value.planType,
    };
  
    // Recalculate the quote amount using RatingService
    this.ratingService.calculateQuote(updatedQuoteDto).subscribe({
      next: (calculated) => {
        const updatedQuote: Quote = {
          ...this.quoteDetails!,
          ...this.quoteForm.value,
          quoteAmount: calculated.quoteAmount, // Set the recalculated amount
          status: true 
        };
  
        // Save the updated quote via the QuoteService
        this.quoteService.editQuote(updatedQuote.id!, updatedQuote).subscribe({
          next: () => {
            this.alertMessage = `Quote updated successfully! New Quote Value: ₹${calculated.quoteAmount}`;
            this.alertType = 'success';
  
            // Display alert for 3 seconds before navigating
            setTimeout(() => {
              this.router.navigate(['/dashboard']); // Navigate back to the dashboard
            }, 3000);
          },
          error: (err) => {
            console.error('Error updating quote:', err);
            this.alertMessage = 'Error updating quote. Please try again!';
            this.alertType = 'error';
          },
        });
      },
      error: (err) => {
        console.error('Error recalculating quote amount:', err);
        this.alertMessage = 'Error recalculating quote amount!';
        this.alertType = 'error';
      },
    });
  }
}