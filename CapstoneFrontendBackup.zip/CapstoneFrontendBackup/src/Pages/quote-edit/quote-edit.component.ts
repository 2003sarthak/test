import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Quote } from '../../shared/Models/Quote.Model';
import { QuoteService } from '../../Services/Quote.Service/quote.service';
import { RatingService } from '../../Services/Rating.Service/rating.service';
import { AlertComponent } from '../../shared/Components/alert/alert.component';

@Component({
  selector: 'app-quote-edit',
  imports: [FormsModule,CommonModule,ReactiveFormsModule,AlertComponent],
  templateUrl: './quote-edit.component.html',
  styleUrl: './quote-edit.component.css'
})

export class QuoteEditComponent {
  quoteForm: FormGroup; 
  quoteDetails: Quote | null = null;
  alertMessage: string | null = null;
  alertType: 'success' | 'error' | null = null;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private quoteService: QuoteService,
    private ratingService: RatingService
  ) {
    // Create the FormGroup with default values or empty controls
    this.quoteForm = new FormGroup({
      businessName: new FormControl('', Validators.required),
      gstNo: new FormControl('', [
        Validators.minLength(15),
        Validators.maxLength(15),
      ]),
      annualTurnover: new FormControl('', [
        Validators.required,
        Validators.min(10000),
      ]),
      businessType: new FormControl('', Validators.required),
      propertyValue: new FormControl('', Validators.required),
      ownershipType: new FormControl('', Validators.required),
      locationType: new FormControl('', Validators.required),
      securitySystem: new FormControl(''),
      previousClaims: new FormControl(''),
      planType: new FormControl('', Validators.required),
      brokerName: new FormControl({ value: '', disabled: true }), 
      brokerId: new FormControl({ value: '', disabled: true }),
      // Newly added fields
      businessAddress: new FormControl('',Validators.required),
      contactPersonName: new FormControl('',Validators.required),
      contactPhoneNumber: new FormControl('',Validators.required),
      email: new FormControl('',Validators.required),
      yearOfOperation: new FormControl('', [Validators.required,Validators.min(1)]),
      numberOfEmployees: new FormControl('', [Validators.required,Validators.min(1)]),
      naturalCalamityCoverageNeeded: new FormControl(false),
      aboutBusiness: new FormControl('',Validators.required), 
    });
  }

  

  ngOnInit() {
    const id = Number(this.route.snapshot.paramMap.get('id')); // Get the quote ID from the route
    if (isNaN(id) || id <= 0) {
      this.alertMessage = 'Invalid Quote ID provided!';
      this.alertType = 'error';
      return;
    }
    this.loadQuoteDetails(id);
  }

  loadQuoteDetails(id: number) {
    // Fetch the quote details by ID from the server
    this.quoteService.getQuoteById(id).subscribe({
      next: (quote) => {
        this.quoteDetails = quote;
        this.updateFormValues(quote);
      },
      error: (err) => {
        console.error('Error loading quote details:', err);
        this.alertMessage = 'Error loading quote details!';
        this.alertType = 'error';
      },
    });
  }

  updateFormValues(quote: Quote) {
    this.quoteForm.patchValue({
      businessName: quote.businessName,
      gstNo: quote.gstNo,
      annualTurnover: quote.annualTurnover,
      businessType: quote.businessType,
      propertyValue: quote.propertyValue,
      ownershipType: quote.ownershipType,
      locationType: quote.locationType,
      securitySystem: quote.securitySystem,
      previousClaims: quote.previousClaims,
      planType: quote.planType,
      brokerName: quote.brokerName,
      brokerId: quote.brokerId,
  
      // Newly added fields
      businessAddress: quote.businessAddress,
      contactPersonName: quote.contactPersonName,
      contactPhoneNumber: quote.contactPhoneNumber,
      email: quote.email,
      yearOfOperation: quote.yearOfOperation,
      numberOfEmployees: quote.numberOfEmployees,
      naturalCalamityCoverageNeeded: quote.naturalCalamityCoverageNeeded,
      aboutBusiness: quote.aboutBusiness,
    });
  }

  saveChanges() {
    if (this.quoteForm.invalid) {
      this.alertMessage = 'Please complete all required fields!';
      this.alertType = 'error';
      return;
    }
  
    const updatedQuoteDto = {
      annualTurnover: this.quoteForm.value.annualTurnover,
      propertyValue: this.quoteForm.value.propertyValue,
      ownershipType: this.quoteForm.value.ownershipType,
      businessType: this.quoteForm.value.businessType,
      locationType: this.quoteForm.value.locationType,
      planType: this.quoteForm.value.planType,
      yearOfOperation: this.quoteForm.value.yearOfOperation, 
      numberOfEmployees: this.quoteForm.value.numberOfEmployees, 
      naturalCalamityCoverageNeeded: this.quoteForm.value.naturalCalamityCoverageNeeded 
    };
  
    // Recalculate the quote amount using RatingService
    this.ratingService.calculateQuote(updatedQuoteDto).subscribe({
      next: (calculated) => {
        const updatedQuote: Quote = {
          ...this.quoteDetails!,
          ...this.quoteForm.value,
          quoteAmount: calculated.quoteAmount, // Set the recalculated amount
          status: true , // Capture breakdown factors from calculated values
        };
  
        // Save the updated quote via the QuoteService
        this.quoteService.editQuote(updatedQuote.id!, updatedQuote).subscribe({
          next: () => {
            this.alertMessage = `Quote updated successfully! New Quote Value: ₹${calculated.quoteAmount}`;
            this.alertType = 'success';
  
            // Display alert for 3 seconds before navigating
            setTimeout(() => {
              this.router.navigate(['/quotelist']); 
            }, 3000);
          },
          error: (err) => {
            console.error('Error updating quote:', err);
            this.alertMessage = 'Error updating quote. Please try again!';
            this.alertType = 'error';
          },
        });
      },
      error: (err) => {
        console.error('Error recalculating quote amount:', err);
        this.alertMessage = 'Error recalculating quote amount!';
        this.alertType = 'error';
      },
    });
  }
}