import { LowerCasePipe, NgFor, NgIf, SlicePipe } from '@angular/common';
import { Component } from '@angular/core';
import { UserServiceService } from '../../Services/User.Service/user-service.service';
import { Router, RouterLink } from '@angular/router';
import { AlertComponent } from '../../shared/Components/alert/alert.component';
import { Quote } from '../../shared/Models/Quote.Model';
import { QuoteService } from '../../Services/Quote.Service/quote.service';

@Component({
  selector: 'app-dashboard',
  imports: [NgFor, LowerCasePipe, NgIf, RouterLink,AlertComponent],
  templateUrl: './dashboard.component.html',
  styleUrl: './dashboard.component.css'
})
export class DashboardComponent {
  constructor(private userService: UserServiceService, private router: Router, private quoteService:QuoteService) { }
  alertMessage: string | null = null;
  alertType: 'success' | 'error' | null = null;
  quotes: {
    id: string;
    businessName: string;
    premium: string;
    status: string;
    created: string;
  }[] = [];
  
  currentPage = 1;
  quotesPerPage = 5;
  filteredQuotes: {
    id: string;
    businessName: string;
    premium: string;
    status: string;
    created: string;
  }[] = [...this.quotes];
  searchQuery = '';
  filterStatus = '';
  sortField = '';
  
  ngOnInit(): void {
    if (!this.userService.getLoggedInUser()) {
      this.router.navigate(['/login']);
    }
    // this.loadQuotesFromLocalStorage();
    this.loadQuotesFromBackend();
    this.applyFilters();
  }
  
  // loadQuotesFromLocalStorage() {
    //   const storedQuotes = localStorage.getItem('submittedQuotes');
    //   if (storedQuotes) {
      //     const submittedQuotes: {
  //       id: string;
  //       businessName: string;
  //       quoteAmount: number;
  //       status: boolean;
  //       createdAt: string;
  //     }[] = JSON.parse(storedQuotes);
  
  //     const formattedQuotes = submittedQuotes.map((quote: {
    //       id: string;
    //       businessName: string;
    //       quoteAmount: number;
    //       status: boolean;
    //       createdAt: string;
    //     }, index: number) => ({
      //       id: quote.id,
      //       businessName: quote.businessName || 'Unknown Business',
      //       premium: quote.quoteAmount ? `₹${quote.quoteAmount.toLocaleString()}` : '₹0', 
      //       status: quote.status ? 'Submitted' : 'Draft',
      //       created: quote.createdAt ? new Date(quote.createdAt).toLocaleDateString() : 'N/A', 
      //     }));
      
      //     this.quotes = [...this.quotes, ...formattedQuotes];
      //   }
      
      //   this.filteredQuotes = [...this.quotes];
      // }
      
      loadQuotesFromBackend() {
        this.quoteService.getQuotes().subscribe(
          (quotes) => {
            const formattedQuotes = quotes.map((quote) => ({
              id: quote.id?.toString() || 'N/A',
              businessName: quote.businessName || 'Unknown Business',
              premium: `₹${quote.quoteAmount?.toLocaleString() || '0'}`,
              status: quote.status ? 'Submitted' : 'Draft',
              created: quote.created ? new Date(quote.created).toLocaleDateString() : 'N/A',
            }));
            this.quotes = formattedQuotes;
            this.filteredQuotes = [...this.quotes];
          },
      (error) => {
        this.alertMessage = 'Failed to load quotes from backend.';
        this.alertType = 'error';
        console.error(error);
      }
    );
  }
  
  paginatedQuotes() {
    const start = (this.currentPage - 1) * this.quotesPerPage;
    const end = start + this.quotesPerPage;
    return this.filteredQuotes.slice(start, end);
  }
  
  totalPages() {
    return Array(Math.ceil(this.filteredQuotes.length / this.quotesPerPage))
    .fill(0)
    .map((x, i) => i + 1);
  }

  goToPage(page: number) {
    this.currentPage = page;
  }
  
  previousPage() {
    if (this.currentPage > 1) {
      this.currentPage--;
    }
  }

  nextPage() {
    if (this.currentPage < this.totalPages().length) {
      this.currentPage++;
    }
  }
  
  onSearch(event: Event) {
    const target = event.target as HTMLInputElement;
    this.searchQuery = target.value.toLowerCase();
    this.applyFilters();
  }

  onFilterStatus(event: Event) {
    const target = event.target as HTMLSelectElement;
    this.filterStatus = target.value;
    this.applyFilters();
  }

  onSort(event: Event) {
    const target = event.target as HTMLSelectElement;
    this.sortField = target.value;
    this.applyFilters();
  }

  applyFilters() {
    this.filteredQuotes = this.quotes.filter((quote) => {
      const matchesSearch =
        quote.businessName.toLowerCase().includes(this.searchQuery) ||
        quote.id.toLowerCase().includes(this.searchQuery);
      const matchesStatus = this.filterStatus
      ? quote.status === this.filterStatus
        : true;
      return matchesSearch && matchesStatus;
    });

    if (this.sortField) {
      this.filteredQuotes.sort((a, b) => {
        if (this.sortField === 'Date') {
          return new Date(a.created).getTime() - new Date(b.created).getTime();
        } else if (this.sortField === 'Premium') {
          return parseFloat(a.premium.replace(/[^0-9.-]+/g, '')) - parseFloat(b.premium.replace(/[^0-9.-]+/g, ''));
        }
        return 0;
      });
    }

    this.currentPage = 1;
  }
  
  onEdit(id: string) {
    this.router.navigate(['/quoteedit', id]); 
  }

  // onDelete(id: string) {
  //   const storedQuotes = JSON.parse(localStorage.getItem('submittedQuotes') || '[]');
  //   const quoteToDelete = storedQuotes.find((quote:{
    //     id: string;
    //     businessName: string;
    //     quoteAmount: number;
    //     status: boolean;
    //     createdAt: string;
    //   })=> quote.id === id);
    
    //   if (quoteToDelete) {
  //     const updatedStoredQuotes = storedQuotes.filter((quote: {
  //       id: string;
  //       businessName: string;
  //       quoteAmount: number;
  //       status: boolean;
  //       createdAt: string;
  //     }) => quote.id !== id);
  //     localStorage.setItem('submittedQuotes', JSON.stringify(updatedStoredQuotes));
  //     this.quotes = this.quotes.filter(quote => quote.id !== id);
  //     this.alertMessage = `Quote "${quoteToDelete.businessName}" deleted successfully!`;
  //     this.alertType = 'success';
  //     this.applyFilters();
  //   } else {
  //     this.alertMessage = 'Quote not found!';
  //     this.alertType = 'error';
  //   }
  // }
  onDelete(id: string) {
    this.quoteService.deleteQuote(Number(id)).subscribe(
      () => {
        this.quotes = this.quotes.filter((quote) => quote.id !== id);
        this.filteredQuotes = [...this.quotes];
        this.alertMessage = 'Quote deleted successfully!';
        this.alertType = 'success';
        this.applyFilters();
      },
      (error) => {
        this.alertMessage = 'Failed to delete the quote.';
        this.alertType = 'error';
        console.error(error);
      }
    );
  }

  onView(id: string) {
    this.router.navigate(['/quotedetails', id]); 
  }
}





    // [
    //   {
    //     id: 'Q-2025-001',
    //     businessName: 'Tech Solutions Inc',
    //     premium: '₹2,450.00',
    //     status: 'Draft',
    //     created: '01/15/2025',
    //   },
    //   {
    //     id: 'Q-2025-002',
    //     businessName: 'Coffee Shop LLC',
    //     premium: '₹1,850.00',
    //     status: 'Submitted',
    //     created: '01/14/2025',
    //   },
    //   {
    //     id: 'Q-2025-003',
    //     businessName: 'Green Energy Corp',
    //     premium: '₹3,200.00',
    //     status: 'Draft',
    //     created: '01/13/2025',
    //   },
    //   {
    //     id: 'Q-2025-004',
    //     businessName: 'Blue Ocean Ltd',
    //     premium: '₹2,100.00',
    //     status: 'Submitted',
    //     created: '01/12/2025',
    //   },
    //   {
    //     id: 'Q-2025-005',
    //     businessName: 'Red Brick Construction',
    //     premium: '₹4,500.00',
    //     status: 'Draft',
    //     created: '01/11/2025',
    //   },
    //   {
    //     id: 'Q-2025-006',
    //     businessName: 'Yellow Sun Solar',
    //     premium: '₹3,750.00',
    //     status: 'Submitted',
    //     created: '01/10/2025',
    //   },
    //   {
    //     id: 'Q-2025-007',
    //     businessName: 'Purple Rain Tech',
    //     premium: '₹2,950.00',
    //     status: 'Draft',
    //     created: '01/09/2025',
    //   },
    //   {
    //     id: 'Q-2025-008',
    //     businessName: 'Orange Grove Farms',
    //     premium: '₹1,650.00',
    //     status: 'Submitted',
    //     created: '01/08/2025',
    //   },
    //   {
    //     id: 'Q-2025-009',
    //     businessName: 'Silver Line Transport',
    //     premium: '₹2,850.00',
    //     status: 'Draft',
    //     created: '01/07/2025',
    //   },
    //   {
    //     id: 'Q-2025-010',
    //     businessName: 'Golden Gate Realty',
    //     premium: '₹3,100.00',
    //     status: 'Submitted',
    //     created: '01/06/2025',
    //   },
    // ];