import { LowerCasePipe, NgFor, NgIf, SlicePipe } from '@angular/common';
import { Component, Renderer2 } from '@angular/core';
import { UserServiceService } from '../../Services/User.Service/user-service.service';
import { Router, RouterLink } from '@angular/router';
import { AlertComponent } from '../../shared/Components/alert/alert.component';
import { QuoteService } from '../../Services/Quote.Service/quote.service';

@Component({
  selector: 'app-dashboard',
  imports: [NgFor, LowerCasePipe, NgIf, RouterLink, AlertComponent],
  templateUrl: './dashboard.component.html',
  styleUrl: './dashboard.component.css'
})
export class DashboardComponent {
  constructor(private userService: UserServiceService, private router: Router, private quoteService: QuoteService) { }
  alertMessage: string | null = null;
  alertType: 'success' | 'error' | null = null;
  quotes: {
    id: string;
    businessName: string;
    premium: string;
    status: string;
    created: string;
  }[] = [];
  brokerQuotes: {
    id: string;
    businessName: string;
    premium: string;
    status: string;
    created: string;
  }[] = [];

  currentPage = 1;
  quotesPerPage = 5;
  filteredQuotes: {
    id: string;
    businessName: string;
    premium: string;
    status: string;
    created: string;
  }[] = [...this.quotes];
  searchQuery = '';
  filterStatus = '';
  sortField = '';
  brokerName='';
  
  totalQuotes = 0;
  submittedQuotes = 0;
  moneyEarned = 0;
  borkerTotalQuotes=0;
  borkerSubmittedQuotes=0;


  ngOnInit(): void {
    if (!this.userService.getLoggedInUser()) {
      this.router.navigate(['/login']);
    }
    this.loadQuotesFromBackend();
    this.loadBrokerQuotes();
    this.applyFilters();
  }

  loadQuotesFromBackend() {
    this.quoteService.getQuotes().subscribe(
      (quotes) => {
        const deletedIds = JSON.parse(localStorage.getItem('deletedQuotes') || '[]');
        const formattedQuotes = quotes.map((quote) => ({
          id: quote.id?.toString() || 'N/A',
          businessName: quote.businessName || 'Unknown Business',
          premium: `₹${quote.quoteAmount?.toLocaleString() || '0'}`,
          status: quote.status ? 'Submitted' : 'Draft',
          created: quote.created ? new Date(quote.created).toLocaleDateString() : 'N/A',
        })).filter((quote) => !deletedIds.includes(Number(quote.id)));
        this.quotes = formattedQuotes;
        this.filteredQuotes = [...this.quotes];
        this.calculateAllQuotesValues();
      },
      (error) => {
        this.alertMessage = 'Failed to load quotes from backend.';
        this.alertType = 'error';
        console.error(error);
      }
    );
  }

  loadBrokerQuotes() {
    const storedLoggedInUser = localStorage.getItem('loggedInUser');
    const userBrokerId = storedLoggedInUser ? JSON.parse(storedLoggedInUser).brokerId : '';
    this.brokerName= storedLoggedInUser ? JSON.parse(storedLoggedInUser).fullName : '';
  
    // console.log(`Broker ID: ${userBrokerId}`);
  
    this.quoteService.getQuotesByBroker(userBrokerId).subscribe(
      (quotes) => {
        const deletedIds = JSON.parse(localStorage.getItem('deletedQuotes') || '[]');
        const formattedQuotes = quotes.map((quote) => ({
          id: quote.id?.toString() || 'N/A',
          businessName: quote.businessName || 'Unknown Business',
          premium: `₹${quote.quoteAmount?.toLocaleString() || '0'}`,
          status: quote.status ? 'Submitted' : 'Draft',
          created: quote.created ? new Date(quote.created).toLocaleDateString() : 'N/A',
        })).filter((quote) => !deletedIds.includes(Number(quote.id)));
        this.brokerQuotes = formattedQuotes;
        this.calculateBrokerQuotesValues();
      },
      (error) => {
        this.alertMessage = 'Failed to load broker-specific quotes.';
        this.alertType = 'error';
        console.error(error);
      }
    );
  }

  calculateAllQuotesValues() {
    this.totalQuotes = this.quotes.length;
    this.submittedQuotes = this.quotes.filter(q => q.status === 'Submitted').length;
  }

  calculateBrokerQuotesValues() {
    this.borkerTotalQuotes = this.brokerQuotes.length;
    this.borkerSubmittedQuotes = this.brokerQuotes.filter(q => q.status === 'Submitted').length;
    this.moneyEarned = this.brokerQuotes.reduce((total, quote) => {
      if (quote.status === 'Submitted') {
        const premiumValue = parseFloat(quote.premium?.toString().replace(/[^0-9.-]+/g, '') || '0');
        return total + (premiumValue * 0.02);
      }
      return total;
    }, 0);
  }

  

  paginatedQuotes() {
    const start = (this.currentPage - 1) * this.quotesPerPage;
    const end = start + this.quotesPerPage;
    return this.filteredQuotes.slice(start, end);
  }

  totalPages() {
    return Array(Math.ceil(this.filteredQuotes.length / this.quotesPerPage))
      .fill(0)
      .map((x, i) => i + 1);
  }

  goToPage(page: number) {
    this.currentPage = page;
  }

  previousPage() {
    if (this.currentPage > 1) {
      this.currentPage--;
    }
  }

  nextPage() {
    if (this.currentPage < this.totalPages().length) {
      this.currentPage++;
    }
  }

  onSearch(event: Event) {
    const target = event.target as HTMLInputElement;
    this.searchQuery = target.value.toLowerCase();
    this.applyFilters();
  }

  onFilterStatus(event: Event) {
    const target = event.target as HTMLSelectElement;
    this.filterStatus = target.value;
    this.applyFilters();
  }

  onSort(event: Event) {
    const target = event.target as HTMLSelectElement;
    this.sortField = target.value;
    this.applyFilters();
  }

  applyFilters() {
    this.filteredQuotes = this.quotes.filter((quote) => {
      const matchesSearch =
        quote.businessName.toLowerCase().includes(this.searchQuery) ||
        quote.id.toLowerCase().includes(this.searchQuery);
      const matchesStatus = this.filterStatus
        ? quote.status === this.filterStatus
        : true;
      return matchesSearch && matchesStatus;
    });

    if (this.sortField) {
      this.filteredQuotes.sort((a, b) => {
        if (this.sortField === 'Date') {
          return new Date(a.created).getTime() - new Date(b.created).getTime();
        } else if (this.sortField === 'Premium') {
          return parseFloat(a.premium.replace(/[^0-9.-]+/g, '')) - parseFloat(b.premium.replace(/[^0-9.-]+/g, ''));
        }
        return 0;
      });
    }

    this.currentPage = 1;
  }

  onView(id: string) {
    this.router.navigate(['/quotedetails', id]);
  }
}










