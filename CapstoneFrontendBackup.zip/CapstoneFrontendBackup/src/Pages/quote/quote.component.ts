import { Component } from '@angular/core';
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { CommonModule, NgIf } from '@angular/common';
import { AlertComponent } from '../../shared/Components/alert/alert.component';
import { UserServiceService } from '../../Services/User.Service/user-service.service';
import { Router } from '@angular/router';
import { QuoteService } from '../../Services/Quote.Service/quote.service';
import { RatingService } from '../../Services/Rating.Service/rating.service';
import { Quote } from '../../shared/Models/Quote.Model';
import { QuoteCalculationDto } from '../../shared/Models/QuoteCalculationDto .Model';
// import jsPDF from 'jspdf';
// import autoTable from 'jspdf-autotable';
import { EmailService } from '../../Services/Email.Service/email.service';

@Component({
  selector: 'app-quote',
  imports: [NgIf,AlertComponent,FormsModule,ReactiveFormsModule,CommonModule],
  templateUrl: './quote.component.html',
  styleUrl: './quote.component.css',
  standalone:true,
})
export class QuoteComponent {
  constructor(
    private userService: UserServiceService,
    private router: Router,
    private quoteService: QuoteService,
    private ratingService: RatingService,
    private emailService:EmailService
  ) {}

  step = 1;
  progress=0;
  alertMessage: string | null = null;
  alertType: 'success' | 'error' | null = null;
  submittedQuote: Quote | null = null;
  quoteDetails: Quote | null = null;
  loggedInUser: any = null;

  quoteAmount: number | null = null;
  baseRate: number | null = null;
  businessTypeRate: number | null = null;
  locationRate: number | null = null;
  propertyRate: number | null = null;
  turnoverComponent: number | null = null;
  finalRate: number | null = null;
  experienceRate: number | null = null;
  employeeRate: number | null = null;
  calamityCoverageRate: number | null = null;

  ngOnInit(): void {
    const user = this.userService.getLoggedInUser();
    if (!user) {
      this.router.navigate(['/login']);
    } else {
      this.loggedInUser = user;
    }
  
    // Restore form data from local storage if available
    const savedFormData = localStorage.getItem('quoteFormData');
    if (savedFormData) {
      this.quoteForm.patchValue(JSON.parse(savedFormData));
    }
  }

  quoteForm = new FormGroup({
    businessName: new FormControl('', Validators.required),
    gstNo: new FormControl('', [Validators.minLength(15), Validators.maxLength(15)]),
    annualTurnover: new FormControl('', [Validators.required, Validators.min(10000)]),
    businessType: new FormControl('Retail', Validators.required),
    propertyValue: new FormControl('', Validators.required),
    ownershipType: new FormControl('Owned', Validators.required),
    locationType: new FormControl('Urban', Validators.required),
    securitySystem: new FormControl('',Validators.required),
    previousClaims: new FormControl('',Validators.required),
    planType: new FormControl('Normal', Validators.required),

    businessAddress: new FormControl('', Validators.required),
    contactPersonName: new FormControl('', Validators.required),
    contactPhoneNumber: new FormControl('', [Validators.required, Validators.pattern(/^[0-9]{10}$/)]),
    email: new FormControl('', [Validators.required, Validators.email]),
    yearOfOperation: new FormControl('', Validators.required),
    numberOfEmployees: new FormControl('', [Validators.required, Validators.min(1)]),
    naturalCalamityCoverageNeeded: new FormControl(false, Validators.required),
    aboutBusiness: new FormControl('', Validators.required),
  });


  //code for next step
  nextStep() {
    if (this.step === 1 && this.quoteForm.controls['businessName'].valid && this.quoteForm.controls['annualTurnover'].valid) {
      this.step++;
    } else if (this.step === 2 && this.quoteForm.controls['propertyValue'].valid && this.quoteForm.controls['ownershipType'].valid && this.quoteForm.controls['locationType'].valid) {
      this.step++;
    } else if (this.step === 3 && this.quoteForm.controls['securitySystem'].valid && this.quoteForm.controls['previousClaims'].valid && this.quoteForm.controls['planType'].valid) {
      this.step++;
    } else if (this.step === 4 && this.quoteForm.controls['businessAddress'].valid && this.quoteForm.controls['contactPersonName'].valid && this.quoteForm.controls['contactPhoneNumber'].valid && this.quoteForm.controls['email'].valid) {
      this.step++;
    } else if (this.step === 5 && this.quoteForm.controls['yearOfOperation'].valid && this.quoteForm.controls['numberOfEmployees'].valid && this.quoteForm.controls['aboutBusiness'].valid) {
      this.calculateQuote(); // Proceed to quote calculation after Step 5
    } else {
      this.alertMessage = 'Please fill in all required fields!';
      this.alertType = 'error';
    }
    this.updateProgress();
  }

  prevStep() {
    if (this.step > 1) {
       this.step--;
       this.updateProgress();
    }
  }
  
  updateProgress() {
    this.progress = (this.step - 1) * 20;
  }
  

  calculateQuote() {
    if (!this.quoteForm.valid) {
      this.alertMessage = 'Please complete all required fields!';
      this.alertType = 'error';
      return;
    }
  
    const formValue = this.quoteForm.value;
  
    // Construct updated Quote DTO including the new fields
    const quoteDto = new QuoteCalculationDto(
      Number(formValue.annualTurnover),
      Number(formValue.propertyValue),
      formValue.ownershipType!,
      formValue.businessType!,
      formValue.locationType!,
      formValue.planType!,
      Number(formValue.yearOfOperation), 
      Number(formValue.numberOfEmployees), 
      formValue.naturalCalamityCoverageNeeded! 
    );
  
    this.ratingService.calculateQuote(quoteDto).subscribe({
      next: (calculated) => {
        this.quoteAmount = calculated.quoteAmount;
        this.baseRate = calculated.breakdown.baseRate;
        this.businessTypeRate = calculated.breakdown.businessTypeRate;
        this.locationRate = calculated.breakdown.locationRate;
        this.propertyRate = calculated.breakdown.propertyRate;
        this.turnoverComponent = calculated.breakdown.turnoverComponent;
        this.finalRate = calculated.breakdown.finalRate;
        this.experienceRate = calculated.breakdown.experienceRate;
        this.employeeRate = calculated.breakdown.employeeRate;
        this.calamityCoverageRate = calculated.breakdown.calamityCoverageRate;
  
        this.alertMessage = 'Quote calculated successfully!';
        this.alertType = 'success';
      },
      error: (err) => {
        this.alertMessage = 'Error calculating quote from server.';
        this.alertType = 'error';
        console.error(err);
      },
    });
  }

  goToTermsandCond() {
    const planType = this.quoteForm.controls['planType'].value;
    if (planType) {
      localStorage.setItem('quoteFormData', JSON.stringify(this.quoteForm.value)); // Save form data
      this.router.navigate(['/term-and-condition'], { queryParams: { policyType: planType } });
    } else {
      this.alertMessage = 'Plan type is missing!';
      this.alertType = 'error';
    }
  }

  // generateQuotePDF(): Blob {
  //   const doc = new jsPDF();
  
  //   const fontSize = 12;
  //   doc.setFont('helvetica', 'normal');
  //   doc.setFontSize(fontSize);
  
  //   doc.setFontSize(16);
  //   doc.text('Quote Details', 14, 20);
  //   doc.setFontSize(fontSize);
  
  //   const details = [
  //     { label: 'Broker ID', value: this.quoteDetails?.brokerId },
  //     { label: 'Broker Name', value: this.quoteDetails?.brokerName },
  //     { label: 'Business Name', value: this.quoteDetails?.businessName },
  //     { label: 'GST Number', value: this.quoteDetails?.gstNo },
  //     { label: 'Annual Turnover', value: `Rs. ${this.quoteDetails?.annualTurnover}` },
  //     { label: 'Property Value', value: `Rs. ${this.quoteDetails?.propertyValue}` },
  //     { label: 'Location Type', value: this.quoteDetails?.locationType },
  //     { label: 'Contact Person', value: this.quoteDetails?.contactPersonName },
  //     { label: 'Phone Number', value: this.quoteDetails?.contactPhoneNumber },
  //     { label: 'Email', value: this.quoteDetails?.email },
  //     { label: 'Business Address', value: this.quoteDetails?.businessAddress },
  //     { label: 'Year of Operation', value: this.quoteDetails?.yearOfOperation },
  //     { label: 'Number of Employees', value: this.quoteDetails?.numberOfEmployees },
  //     { label: 'Natural Calamity Coverage Needed', value: this.quoteDetails?.naturalCalamityCoverageNeeded ? 'Yes' : 'No' },
  //     { label: 'About Business', value: this.quoteDetails?.aboutBusiness },
  //     { label: 'Plan Type', value: this.quoteDetails?.planType },
  //     { label: 'Quote Amount', value: `Rs. ${this.quoteDetails?.quoteAmount}` },
  //     { label: 'Status', value: this.quoteDetails?.status ? 'Submitted' : 'Draft' },
  //   ];
  
  //   details.forEach((detail, index) => {
  //     doc.text(`${detail.label}: ${detail.value}`, 14, 30 + index * 10);
  //   });
  
  //   if (this.baseRate || this.businessTypeRate || this.locationRate || this.experienceRate || this.employeeRate || this.calamityCoverageRate) {
  //     const breakdownTable = [
  //       ['Property Value', `Rs. ${this.propertyRate || 0}`],
  //       ['Base Rate', `${(this.baseRate || 0) * 100}%`],
  //       ['Business Type Adjustment', `${(this.businessTypeRate || 0) * 100}%`],
  //       ['Location Adjustment', `${(this.locationRate || 0) * 100}%`],
  //       ['Years of Operation Adjustment', `${(this.experienceRate || 0) * 100}%`],
  //       ['Employee Count Adjustment', `${(this.employeeRate || 0) * 100}%`],
  //       ['Natural Calamity Coverage Adjustment', `${(this.calamityCoverageRate || 0) * 100}%`],
  //       ['Total Adjustment', `${(this.finalRate || 0) * 100}%`],
  //     ];
  
  //     autoTable(doc, {
  //       startY: 30 + details.length * 10,
  //       head: [['Factor', 'Percentage/Adjustment']],
  //       body: breakdownTable,
  //       styles: {
  //         font: 'helvetica',
  //         fontSize: fontSize,
  //       },
  //     });
  //   }
  
  //   return doc.output('blob'); // Generate a Blob instead of saving
  // }

  submitQuote() {
    if (!this.quoteForm.valid || this.quoteAmount === null) {
      this.alertMessage = 'Please calculate the quote before submitting!';
      this.alertType = 'error';
      return;
    }
  
    const formValue = this.quoteForm.value;
  
    const newQuote: Quote = {
      brokerName: this.loggedInUser.fullName,
      brokerId: this.loggedInUser.brokerId,
      businessName: formValue.businessName!,
      gstNo: formValue.gstNo!,
      annualTurnover: Number(formValue.annualTurnover),
      propertyValue: Number(formValue.propertyValue),
      ownershipType: formValue.ownershipType!,
      businessType: formValue.businessType!,
      locationType: formValue.locationType!,
      securitySystem: formValue.securitySystem!,
      previousClaims: formValue.previousClaims!,
      securityMeasures: true, 
      planType: formValue.planType as 'Normal' | 'Gold' | 'Premium',
      quoteAmount: this.quoteAmount,
      status: false,
      created: new Date(),

      //newly added fields 
      businessAddress: formValue.businessAddress!,
      contactPersonName: formValue.contactPersonName!,
      contactPhoneNumber: formValue.contactPhoneNumber!,
      email: formValue.email!,
      yearOfOperation: Number(formValue.yearOfOperation),
      numberOfEmployees: Number(formValue.numberOfEmployees),
      naturalCalamityCoverageNeeded: Boolean(formValue.naturalCalamityCoverageNeeded),
      aboutBusiness: formValue.aboutBusiness!,
    };
  
    this.quoteService.createQuote(newQuote).subscribe({
      next: (response) => {
        this.submittedQuote = response;
        this.alertMessage = 'Quote submitted successfully!';
        this.alertType = 'success';
        // Generate PDF and send via email
        // const pdfBlob = this.generateQuotePDF();
        this.emailService.sendQuoteEmail(newQuote.email, newQuote.brokerName, newQuote);
        this.quoteForm.reset();
        localStorage.removeItem('quoteFormData');
        this.step = 1;
        this.quoteAmount = null; 
        setTimeout(() => {
          this.router.navigate(['/dashboard']); 
        }, 3000);
      },
      error: (err) => {
        this.alertMessage = 'Error submitting quote to server.';
        this.alertType = 'error';
        console.error(err);
      },
    });
  }


  

  // Submit quote using backend calculation and quote services
  // submitQuote() {
  //   if (!this.quoteForm.valid || !this.loggedInUser) {
  //     this.alertMessage = 'Please complete all required fields!';
  //     this.alertType = 'error';
  //     return;
  //   }
  //   console.log(this.loggedInUser);
  //   const formValue = this.quoteForm.value;

  //   const quoteDto = new QuoteCalculationDto(
  //     Number(formValue.annualTurnover),
  //     Number(formValue.propertyValue),
  //     formValue.ownershipType!,
  //     formValue.businessType!,
  //     formValue.locationType!,
  //     formValue.planType!
  //   );
  //   console.log(quoteDto);

  //   this.ratingService.calculateQuote(quoteDto).subscribe({
  //     next: (calculated) => {
  //       this.quoteAmount = calculated.quoteAmount;
  //       this.baseRate = calculated.breakdown.baseRate;
  //       this.businessTypeRate = calculated.breakdown.businessTypeRate;
  //       this.locationRate = calculated.breakdown.locationRate;
  //       this.propertyRate = calculated.breakdown.propertyRate;
  //       this.turnoverComponent = calculated.breakdown.turnoverComponent;
  //       this.finalRate = calculated.breakdown.finalRate;
  //       const newQuote: Quote = {
  //         // id: '', // Will be set by backend
  //         brokerName: this.loggedInUser.fullName,
  //         brokerId: this.loggedInUser.brokerId,
  //         businessName: formValue.businessName!,
  //         gstNo: formValue.gstNo!,
  //         annualTurnover: Number(formValue.annualTurnover),
  //         propertyValue: Number(formValue.propertyValue),
  //         ownershipType: formValue.ownershipType!,
  //         businessType: formValue.businessType!,
  //         locationType: formValue.locationType!,
  //         securitySystem: formValue.securitySystem!,
  //         previousClaims: formValue.previousClaims!,
  //         securityMeasures: true, // Add actual logic if needed
  //         planType: formValue.planType as 'Normal' | 'Gold' | 'Premium',
  //         quoteAmount: calculated.quoteAmount,
  //         status: false,
  //         created: new Date(),
  //       };
  //       console.log(newQuote);
  //       this.quoteService.createQuote(newQuote).subscribe({
  //         next: (response) => {
  //           console.log(this.quoteForm);
  //           this.submittedQuote = response;
  //           this.alertMessage = 'Quote submitted successfully!';
  //           this.alertType = 'success';
  //           this.quoteForm.reset();
  //           this.step = 1;
  //         },
  //         error: (err) => {
  //           console.log(this.quoteForm);
  //           this.alertMessage = 'Error submitting quote to server.';
  //           this.alertType = 'error';
  //           console.error(err);
  //         }
  //       });
  //     },
  //     error: (err) => {
  //       console.log(this.quoteForm);
  //       this.alertMessage = 'Error calculating quote from server.';
  //       this.alertType = 'error';
  //       console.error(err);
  //     }
  //   });
  // }
}




// export class QuoteComponent {
//   constructor(
//     private userService: UserServiceService,
//     private router: Router,
//   ) {}

//   step = 1;
//   alertMessage: string | null = null;
//   alertType: 'success' | 'error' | null = null;
//   submittedQuote: any = null;
//   submittedQuotes: any[] = JSON.parse(localStorage.getItem('submittedQuotes') || '[]');
//   loggedInUser: any = null;

//   ngOnInit(): void {
//     const user = this.userService.getLoggedInUser();
//     if (!this.userService.getLoggedInUser()) {
//       this.router.navigate(['/login']);
//     }else {
//       this.loggedInUser = user; 
//     }

//   }

//   // Define the form group with all controls
//   quoteForm = new FormGroup({
//     businessName: new FormControl('', Validators.required),
//     gstNo:new FormControl('',[Validators.minLength(15),Validators.maxLength(15)]),
//     annualTurnover: new FormControl('', [Validators.required, Validators.min(10000)]),
//     businessType: new FormControl('Retail', Validators.required),
//     propertyValue: new FormControl('', Validators.required),
//     ownershipType: new FormControl('Owned', Validators.required),
//     locationType: new FormControl('Urban', Validators.required),
//     securitySystem: new FormControl(''),
//     previousClaims: new FormControl(''),
//     planType: new FormControl('Normal', Validators.required),
//   });

//   // Variables for displaying breakdown in the summary
//   baseRate = 0.005;
//   businessTypeRate = 0;
//   propertyRate = 0;
//   propertyPer = 0;
//   locationRate = 0;
//   finalRate = 0;
//   finalValue = 0;

//   // Step Navigation Methods
//   nextStep() {
//     if (this.step === 1 && this.quoteForm.controls['businessName'].valid && this.quoteForm.controls['annualTurnover'].valid) {
//       this.step++;
//     } else if (this.step === 2 && this.quoteForm.controls['propertyValue'].valid) {
//       this.step++;
//     } else {
//       this.alertMessage = 'Please fill in all required fields!';
//       this.alertType = 'error';
//     }
//   }

//   prevStep() {
//     this.step--;
//   }

//   // Quote Calculation
//   calculateQuote() {
//     this.baseRate = 0.005; // 0.1%

//     // Plan type adjustment
//     switch (this.quoteForm.value.planType) {
//       case 'Gold':
//         this.baseRate = 0.01;
//         break;
//       case 'Premium':
//         this.baseRate = 0.015;
//         break;
//     }

//     // Business type adjustment
//     switch (this.quoteForm.value.businessType) {
//       case 'Retail':
//         this.businessTypeRate = 0.0025;
//         break;
//       case 'Manufacturing':
//         this.businessTypeRate = 0.005;
//         break;
//       case 'High Risk':
//         this.businessTypeRate = 0.0075;
//         break;
//     }

//     // Property value adjustment
//     this.propertyPer= 0.0005; 
//     if (this.quoteForm.value.ownershipType === 'Owned') {
//       this.propertyPer += 0.00025; 
//     } else if (this.quoteForm.value.ownershipType === 'Rented') {
//       this.propertyPer -= 0.00025;
//     }
//     this.propertyRate = Number(this.quoteForm.value.propertyValue)*this.propertyPer ;

//     // Location type adjustment
//     switch (this.quoteForm.value.locationType) {
//       case 'Urban':
//         this.locationRate = 0.0025;
//         break;
//       case 'Semiurban':
//         this.locationRate = 0.005;
//         break;
//       case 'Rural':
//         this.locationRate = 0.0075;
//         break;
//     }

//     // Calculate final rate
//     this.finalRate =
//       this.baseRate + this.businessTypeRate + this.locationRate;
    
//     this.finalValue=Math.round(Number(this.quoteForm.value.annualTurnover) * this.finalRate);

//     // Calculate the quote
//     return this.finalValue + this.propertyRate;
//   }

//   submitQuote() {
//     if (this.quoteForm.valid) {
//       const currentDate = new Date(); 
//       const id = `Q-2025-${this.submittedQuotes.length + 1}`;
//       const users = JSON.parse(localStorage.getItem('users') || '[]');
//       const brokerIndex = users.findIndex((user: any) => user.fullName === this.loggedInUser.fullName);
//       const brokerId = `Bro00${brokerIndex}`;
//       const brokerName = this.loggedInUser.fullName;
      
//       this.submittedQuote = {
//         ...this.quoteForm.value,
//         quoteAmount: this.calculateQuote(),
//         status: false, 
//         createdAt: currentDate.toISOString(), 
//         id: id,
//         brokerName: brokerName,
//         brokerId: brokerId,
//       };
//       const newQuote = {
//         ...this.quoteForm.value,
//         quoteAmount: this.calculateQuote(),
//         status: false, 
//         createdAt: currentDate.toISOString(),
//         id: id,
//         brokerName: brokerName,
//         brokerId: brokerId,
//       };
//       this.submittedQuotes.push(newQuote);
//       localStorage.setItem('submittedQuotes', JSON.stringify(this.submittedQuotes));
//       this.alertMessage = 'Quote submitted successfully!';
//       this.alertType = 'success';
//       //reset the form 
//       this.quoteForm.reset();
//       this.step = 1; 
//     } else {
//       this.alertMessage = 'Please complete all required fields!';
//       this.alertType = 'error';
//     }
//   }

// }
