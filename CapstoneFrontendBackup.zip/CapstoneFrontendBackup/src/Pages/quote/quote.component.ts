import { Component } from '@angular/core';
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { CommonModule, NgIf } from '@angular/common';
import { AlertComponent } from '../../shared/Components/alert/alert.component';
import { UserServiceService } from '../../Services/User.Service/user-service.service';
import { Router } from '@angular/router';
import { QuoteService } from '../../Services/Quote.Service/quote.service';
import { RatingService } from '../../Services/Rating.Service/rating.service';
import { Quote } from '../../shared/Models/Quote.Model';
import { QuoteCalculationDto } from '../../shared/Models/QuoteCalculationDto .Model';
import { EmailService } from '../../Services/Email.Service/email.service';
import { QuoteUpgradeDialogComponent } from '../../shared/Components/quote-upgrade-dialog/quote-upgrade-dialog.component';
import * as pdfjsLib from 'pdfjs-dist';
pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/2.16.105/pdf.worker.min.js';

@Component({
  selector: 'app-quote',
  imports: [NgIf, AlertComponent,QuoteUpgradeDialogComponent, FormsModule, ReactiveFormsModule, CommonModule],
  templateUrl: './quote.component.html',
  styleUrl: './quote.component.css',
  standalone: true,
})
export class QuoteComponent {
  constructor(
    private userService: UserServiceService,
    private router: Router,
    private quoteService: QuoteService,
    private ratingService: RatingService,
    private emailService: EmailService
  ) { }

  step = 1;
  progress = 0;
  fileName: string | null = null;
  alertMessage: string | null = null;
  alertType: 'success' | 'error' | null = null;
  submittedQuote: Quote | null = null;
  quoteDetails: Quote | null = null;
  loggedInUser: any = null;
  normalQuotedAmount: number | null = null;
  goldQuotedAmount: number | null = null;
  premiumQuotedAmount: number | null = null;
  showUpgradeDialog = false;

  quoteAmount: number | null = null;
  baseRate: number | null = null;
  businessTypeRate: number | null = null;
  locationRate: number | null = null;
  propertyRate: number | null = null;
  turnoverComponent: number | null = null;
  finalRate: number | null = null;
  experienceRate: number | null = null;
  employeeRate: number | null = null;
  calamityCoverageRate: number | null = null;

  ngOnInit(): void {
    const user = this.userService.getLoggedInUser();
    if (!user) {
      this.router.navigate(['/login']);
    } else {
      this.loggedInUser = user;
    }

    // Restore form data from local storage if available
    const savedFormData = localStorage.getItem('quoteFormData');
    if (savedFormData) {
      this.quoteForm.patchValue(JSON.parse(savedFormData));
    }
  }

  quoteForm = new FormGroup({
    businessName: new FormControl('', Validators.required),
    gstNo: new FormControl('', [Validators.minLength(15), Validators.maxLength(15)]),
    annualTurnover: new FormControl('', [
      Validators.required,
      Validators.min(10000),
      Validators.pattern(/^\d+(\.\d{1,2})?$/) // Accepts integers or decimals with up to 2 decimal places
    ]),
    businessType: new FormControl('Retail', Validators.required),
    propertyValue: new FormControl('', [
      Validators.required,
      Validators.pattern(/^\d+(\.\d{1,2})?$/)
    ]),
    ownershipType: new FormControl('Owned', Validators.required),
    locationType: new FormControl('Urban', Validators.required),
    securitySystem: new FormControl('', Validators.required),
    previousClaims: new FormControl('', Validators.required),
    planType: new FormControl('Normal', Validators.required),
  
    businessAddress: new FormControl('', Validators.required),
    contactPersonName: new FormControl('', Validators.required),
    contactPhoneNumber: new FormControl('', [
      Validators.required,
      Validators.pattern(/^[0-9]{10}$/)
    ]),
    email: new FormControl('', [Validators.required, Validators.email]),
    yearOfOperation: new FormControl('', [
      Validators.required,
      Validators.pattern(/^\d+$/) // Accepts integers only
    ]),
    numberOfEmployees: new FormControl('', [
      Validators.required,
      Validators.min(1),
      Validators.pattern(/^\d+$/) // Accepts integers only
    ]),
    naturalCalamityCoverageNeeded: new FormControl(false, Validators.required),
    aboutBusiness: new FormControl('', Validators.required),
  });


  //code for next step
  nextStep() {
    if (this.step === 1 && this.quoteForm.controls['businessName'].valid && this.quoteForm.controls['annualTurnover'].valid) {
      this.step++;
    } else if (this.step === 2 && this.quoteForm.controls['propertyValue'].valid && this.quoteForm.controls['ownershipType'].valid && this.quoteForm.controls['locationType'].valid) {
      this.step++;
    } else if (this.step === 3 && this.quoteForm.controls['securitySystem'].valid && this.quoteForm.controls['previousClaims'].valid && this.quoteForm.controls['planType'].valid) {
      this.step++;
    } else if (this.step === 4 && this.quoteForm.controls['businessAddress'].valid && this.quoteForm.controls['contactPersonName'].valid && this.quoteForm.controls['contactPhoneNumber'].valid && this.quoteForm.controls['email'].valid) {
      this.step++;
    } else if (this.step === 5 && this.quoteForm.controls['yearOfOperation'].valid && this.quoteForm.controls['numberOfEmployees'].valid && this.quoteForm.controls['aboutBusiness'].valid) {
      this.calculateQuote(); // Proceed to quote calculation after Step 5
    } else {
      this.alertMessage = 'Please fill in all required fields!';
      this.alertType = 'error';
    }
    this.updateProgress();
  }

  prevStep() {
    if (this.step > 1) {
      this.step--;
      this.updateProgress();
    }
  }

  updateProgress() {
    this.progress = (this.step - 1) * 20;
  }

  onPdfUpload(event: any): void {
    const file = event.target.files[0];
    if (file) {
      this.fileName=file.name;
      const reader = new FileReader();
      reader.onload = async (e: any) => {
        const typedArray = new Uint8Array(e.target.result);
        const pdf = await pdfjsLib.getDocument(typedArray).promise;
        let text = '';
  
        // Extract text content from each page of the PDF
        for (let pageNum = 1; pageNum <= pdf.numPages; pageNum++) {
          const page = await pdf.getPage(pageNum);
          const textContent = await page.getTextContent();
          textContent.items.forEach((item: any) => {
            text += item.str + ' ';
          });
        }
  
        // Convert extracted text into JSON
        const formData = this.populateFormFromPdf(text);
        console.log('Parsed Data:', formData); // Debugging
  
        // Populate the form
        this.quoteForm.patchValue(formData);
      };
      reader.readAsArrayBuffer(file);
    }
  }
  
  populateFormFromPdf(text: string): any {
    // console.log('Extracted PDF Text:', text); // For debugging
  
    // Match Business Name and take the first word
    const businessNameMatch = text.match(/Business Name:\s*([^\n]+)/i);
    if (businessNameMatch) {
      const firstWord = businessNameMatch[1].trim().split(' ')[0];
      this.quoteForm.controls['businessName'].setValue(firstWord);
    }
  
    // Match GST Number and take the first word
    const gstNoMatch = text.match(/GST Number:\s*([^\n]+)/i);
    if (gstNoMatch) {
      const firstWord = gstNoMatch[1].trim().split(' ')[0];
      this.quoteForm.controls['gstNo'].setValue(firstWord);
    }
  
    // Match Annual Turnover and take the first word
    const annualTurnoverMatch = text.match(/Annual Turnover:\s*Rs.\s*(\d+)/i);
    if (annualTurnoverMatch) {
      const firstWord = annualTurnoverMatch[1].trim().split(' ')[0];
      this.quoteForm.controls['annualTurnover'].setValue(firstWord);
    }
  
    // Match Property Value and take the first word
    const propertyValueMatch = text.match(/Property Value:\s*Rs.\s*(\d+)/i);
    if (propertyValueMatch) {
      const firstWord = propertyValueMatch[1].trim().split(' ')[0];
      this.quoteForm.controls['propertyValue'].setValue(firstWord);
    }

    // Match Security Systems and take the first word
    const securitySystemMatch = text.match(/Security Systems:\s*([^\n]+)/i);
    if (securitySystemMatch) {
      const firstWord = securitySystemMatch[1].trim().split(' ')[0];
      this.quoteForm.controls['securitySystem'].setValue(firstWord);
    }
    // Match Previous Claims and take the first word
    const previousClaimsMatch = text.match(/Previous Claims:\s*([^\n]+)/i);
    if (previousClaimsMatch) {
      const firstWord = previousClaimsMatch[1].trim().split(' ')[0];
      this.quoteForm.controls['previousClaims'].setValue(firstWord);
    }
  
    // Match Contact Person Name and take the first word
    const contactPersonMatch = text.match(/Contact Person:\s*([^\n]+)/i);
    if (contactPersonMatch) {
      const firstWord = contactPersonMatch[1].trim().split(' ')[0];
      this.quoteForm.controls['contactPersonName'].setValue(firstWord);
    }
  
    // Match Phone Number and take the first word
    const phoneNumberMatch = text.match(/Phone Number:\s*(\d{10})/i);
    if (phoneNumberMatch) {
      const firstWord = phoneNumberMatch[1].trim().split(' ')[0];
      this.quoteForm.controls['contactPhoneNumber'].setValue(firstWord);
    }
  
    // Match Email and take the first word
    const emailMatch = text.match(/Email:\s*([^\n]+)/i);
    if (emailMatch) {
      const firstWord = emailMatch[1].trim().split(' ')[0];
      this.quoteForm.controls['email'].setValue(firstWord);
    }
  
    // Match Business Address and take the first word
    const businessAddressMatch = text.match(/Business Address:\s*([^\n]+)/i);
    if (businessAddressMatch) {
      const firstWord = businessAddressMatch[1].trim().split(' ')[0];
      this.quoteForm.controls['businessAddress'].setValue(firstWord);
    }
  
    // Match Year of Operation and take the first word
    const yearOfOperationMatch = text.match(/Year of Operation:\s*(\d+)/i);
    if (yearOfOperationMatch) {
      const firstWord = yearOfOperationMatch[1].trim().split(' ')[0];
      this.quoteForm.controls['yearOfOperation'].setValue(firstWord);
    }
  
    // Match Number of Employees and take the first word
    const numberOfEmployeesMatch = text.match(/Number of Employees:\s*(\d+)/i);
    if (numberOfEmployeesMatch) {
      const firstWord = numberOfEmployeesMatch[1].trim().split(' ')[0];
      this.quoteForm.controls['numberOfEmployees'].setValue(firstWord);
    }
  
    // Match Natural Calamity Coverage Needed and take the first word
    const naturalCalamityCoverageMatch = text.match(/Natural Calamity Coverage Needed:\s*(Yes|No)/i);
    if (naturalCalamityCoverageMatch) {
      const firstWord = naturalCalamityCoverageMatch[1].trim().split(' ')[0];
      this.quoteForm.controls['naturalCalamityCoverageNeeded'].setValue(firstWord.toLowerCase() === 'yes');
    }
  
    // Match About Business and take the first word
    const aboutBusinessMatch = text.match(/About Business:\s*([^\n]+)/i);
    if (aboutBusinessMatch) {
      const firstWord = aboutBusinessMatch[1].trim().split(' ')[0];
      this.quoteForm.controls['aboutBusiness'].setValue(firstWord);
    }
  
    // Match Plan Type and take the first word
    const planTypeMatch = text.match(/Plan Type:\s*(Normal|Gold|Premium)/i);
    if (planTypeMatch) {
      const firstWord = planTypeMatch[1].trim().split(' ')[0];
      this.quoteForm.controls['planType'].setValue(firstWord);
    }
  }


  calculateQuotesForAllPlans(): Promise<void> {
    return new Promise((resolve, reject) => {
      if (!this.quoteForm.valid) {
        this.alertMessage = 'Please complete all required fields!';
        this.alertType = 'error';
        reject('Form is invalid');
        return;
      }
  
      const formValue = this.quoteForm.value;
      const plans = ['Normal', 'Gold', 'Premium'];
      
      // Create an array of Promises for all plans
      const quotePromises = plans.map((plan) => {
        const quoteDto = new QuoteCalculationDto(
          Number(formValue.annualTurnover),
          Number(formValue.propertyValue),
          formValue.ownershipType!,
          formValue.businessType!,
          formValue.locationType!,
          plan,
          Number(formValue.yearOfOperation),
          Number(formValue.numberOfEmployees),
          formValue.naturalCalamityCoverageNeeded!
        );
  
        return this.ratingService.calculateQuote(quoteDto).toPromise()
          .then((calculated) => {
            if (plan === 'Normal') {
              this.normalQuotedAmount = calculated.quoteAmount;
            } else if (plan === 'Gold') {
              this.goldQuotedAmount = calculated.quoteAmount;
            } else if (plan === 'Premium') {
              this.premiumQuotedAmount = calculated.quoteAmount;
            }
          })
          .catch((err) => {
            console.error(`Error calculating ${plan} quote from server:`, err);
            throw err; // Ensure rejection propagates
          });
      });
  
      // Wait for all Promises to resolve
      Promise.all(quotePromises)
        .then(() => {
          console.log(`Final Values: Normal=${this.normalQuotedAmount}, Gold=${this.goldQuotedAmount}, Premium=${this.premiumQuotedAmount}`);
          resolve(); // Resolve the main Promise
        })
        .catch((err) => {
          reject(err); // Reject if any of the Promises fail
        });
    });
  }
  async calculateQuote() {
    await this.calculateQuotesForAllPlans(); // Wait for all plan calculations
      console.log(`Now using values: Normal=${this.normalQuotedAmount}, Gold=${this.goldQuotedAmount}, Premium=${this.premiumQuotedAmount}`);
    if (!this.quoteForm.valid) {
      this.alertMessage = 'Please complete all required fields!';
      this.alertType = 'error';
      return;
    }

    const formValue = this.quoteForm.value;

    // Construct updated Quote DTO including the new fields
    const quoteDto = new QuoteCalculationDto(
      Number(formValue.annualTurnover),
      Number(formValue.propertyValue),
      formValue.ownershipType!,
      formValue.businessType!,
      formValue.locationType!,
      formValue.planType!,
      Number(formValue.yearOfOperation),
      Number(formValue.numberOfEmployees),
      formValue.naturalCalamityCoverageNeeded!
    );

    this.ratingService.calculateQuote(quoteDto).subscribe({
      next: (calculated) => {
        this.quoteAmount = calculated.quoteAmount;
        this.baseRate = calculated.breakdown.baseRate;
        this.businessTypeRate = calculated.breakdown.businessTypeRate;
        this.locationRate = calculated.breakdown.locationRate;
        this.propertyRate = calculated.breakdown.propertyRate;
        this.turnoverComponent = calculated.breakdown.turnoverComponent;
        this.finalRate = calculated.breakdown.finalRate;
        this.experienceRate = calculated.breakdown.experienceRate;
        this.employeeRate = calculated.breakdown.employeeRate;
        this.calamityCoverageRate = calculated.breakdown.calamityCoverageRate;

        this.alertMessage = 'Quote calculated successfully!';
        this.alertType = 'success';

        if (formValue.planType !== 'Premium') {
          setTimeout(() => {
            this.showUpgradeDialog = true;
          }, 10000); // Show after 10 seconds
        }
      },
      error: (err) => {
        this.alertMessage = 'Error calculating quote from server.';
        this.alertType = 'error';
        console.error(err);
      },
    });
  }

  goToTermsandCond() {
    const planType = this.quoteForm.controls['planType'].value;
    const naturalCalamityCoverageNeeded = this.quoteForm.controls['naturalCalamityCoverageNeeded'].value;

    if (planType) {
      localStorage.setItem('quoteFormData', JSON.stringify(this.quoteForm.value)); // Save form data

      // Pass query parameters as a single object
      this.router.navigate(['/term-and-condition'], {
        queryParams: {
          policyType: planType,
          naturalCalamityCoverageNeeded: naturalCalamityCoverageNeeded
        }
      });
    } else {
      this.alertMessage = 'Plan type is missing!';
      this.alertType = 'error';
    }
  }

  submitQuote() {
    if (!this.quoteForm.valid || this.quoteAmount === null) {
      this.alertMessage = 'Please calculate the quote before submitting!';
      this.alertType = 'error';
      return;
    }

    const formValue = this.quoteForm.value;

    const newQuote: Quote = {
      brokerName: this.loggedInUser.fullName,
      brokerId: this.loggedInUser.brokerId,
      businessName: formValue.businessName!,
      gstNo: formValue.gstNo!,
      annualTurnover: Number(formValue.annualTurnover),
      propertyValue: Number(formValue.propertyValue),
      ownershipType: formValue.ownershipType!,
      businessType: formValue.businessType!,
      locationType: formValue.locationType!,
      securitySystem: formValue.securitySystem!,
      previousClaims: formValue.previousClaims!,
      securityMeasures: true,
      planType: formValue.planType as 'Normal' | 'Gold' | 'Premium',
      quoteAmount: this.quoteAmount,
      status: false,
      created: new Date(),

      //newly added fields 
      businessAddress: formValue.businessAddress!,
      contactPersonName: formValue.contactPersonName!,
      contactPhoneNumber: formValue.contactPhoneNumber!,
      email: formValue.email!,
      yearOfOperation: Number(formValue.yearOfOperation),
      numberOfEmployees: Number(formValue.numberOfEmployees),
      naturalCalamityCoverageNeeded: Boolean(formValue.naturalCalamityCoverageNeeded),
      aboutBusiness: formValue.aboutBusiness!,
    };

    this.quoteService.createQuote(newQuote).subscribe({
      next: (response) => {
        this.submittedQuote = response;
        this.alertMessage = 'Quote submitted successfully!';
        this.alertType = 'success';
        this.emailService.sendQuoteEmail(newQuote.email, newQuote.brokerName, newQuote);
        this.quoteForm.reset();
        localStorage.removeItem('quoteFormData');
        this.step = 1;
        this.quoteAmount = null;
        setTimeout(() => {
          this.router.navigate(['/dashboard']);
        }, 3000);
      },
      error: (err) => {
        this.alertMessage = 'Error submitting quote to server.';
        this.alertType = 'error';
        console.error(err);
      },
    });
  }
}
