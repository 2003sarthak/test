import { NgFor, NgIf } from '@angular/common';
import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';


interface PolicyTerms {
  type: string;
  claimPercentage: number;
  description: string;
  extraCoverages?: string[];
}
@Component({
  selector: 'app-terms-and-condition',
  imports: [NgFor,NgIf],
  templateUrl: './terms-and-condition.component.html',
  styleUrl: './terms-and-condition.component.css'
})
export class TermsAndConditionComponent {
  selectedPolicyType: string | null = null;
  policies: PolicyTerms[] = [];
  commonCoverages: string[] = [];

  constructor(private route: ActivatedRoute) {}

  ngOnInit(): void {
    this.route.queryParamMap.subscribe(params => {
      this.selectedPolicyType = params.get('policyType');
      this.loadPolicies();
      this.loadCommonCoverages();
    });
  }

  loadPolicies() {
    const allPolicies: PolicyTerms[] = [
      {
        type: 'Normal',
        claimPercentage: 60,
        description: 'Provides coverage up to 60% of losses incurred due to insured risks such as theft, fire, or natural disasters.'
      },
      {
        type: 'Gold',
        claimPercentage: 80,
        description: 'Offers up to 80% reimbursement on claims for a broader range of damages.',
        extraCoverages: ['Accidental Losses', 'Minor Damage Coverage']
      },
      {
        type: 'Premium',
        claimPercentage: 100,
        description: 'Covers 100% of eligible losses including business interruption and accidental losses.',
        extraCoverages: ['Accidental Losses', 'Minor Damage Coverage', 'Business Interruption']
      }
    ];

    if (this.selectedPolicyType) {
      this.policies = allPolicies.filter(p => p.type === this.selectedPolicyType);
    } else {
      this.policies = allPolicies;
    }
  }

  loadCommonCoverages() {
    this.commonCoverages = [
      'Property Damage',
      'Third-Party Liability',
      'Theft and Burglary',
      'Equipment Breakdown',
      'Public Liability',
      'Employee Compensation'
    ];
  }

}
