import { Component } from '@angular/core';
import { UserServiceService } from '../../Services/User.Service/user-service.service';
import { Router, RouterLink } from '@angular/router';
import { QuoteService } from '../../Services/Quote.Service/quote.service';
import { AlertComponent } from '../../shared/Components/alert/alert.component';
import { LowerCasePipe, NgFor, NgIf } from '@angular/common';

@Component({
  selector: 'app-quote-list',
  imports: [NgFor, LowerCasePipe, NgIf, RouterLink,AlertComponent],
  templateUrl: './quote-list.component.html',
  styleUrl: './quote-list.component.css'
})
export class QuoteListComponent {
  constructor(private userService: UserServiceService, private router: Router, private quoteService:QuoteService) { }
    alertMessage: string | null = null;
    alertType: 'success' | 'error' | null = null;
    quotes: {
      id: string;
      businessName: string;
      premium: string;
      status: string;
      created: string;
    }[] = [];
    
    currentPage = 1;
    quotesPerPage = 5;
    filteredQuotes: {
      id: string;
      businessName: string;
      premium: string;
      status: string;
      created: string;
    }[] = [...this.quotes];
    searchQuery = '';
    filterStatus = '';
    sortField = '';
    brokerName='';
    
    ngOnInit(): void {
      if (!this.userService.getLoggedInUser()) {
        this.router.navigate(['/login']);
      }
      this.loadQuotesFromBackend();
      this.applyFilters();
    }
        
    loadQuotesFromBackend() {
      const storedLoggedInUser = localStorage.getItem('loggedInUser');
      const userBrokerId = storedLoggedInUser ? JSON.parse(storedLoggedInUser).brokerId : '';
      this.brokerName= storedLoggedInUser ? JSON.parse(storedLoggedInUser).fullName : '';

      // console.log(userBrokerId);
    
      this.quoteService.getQuotesByBroker(userBrokerId).subscribe(
        (quotes) => {
          // console.log(quotes);
          const deletedIds = JSON.parse(localStorage.getItem('deletedQuotes') || '[]');
          const formattedQuotes = quotes
            .map((quote) => ({
              id: quote.id?.toString() || 'N/A',
              businessName: quote.businessName || 'Unknown Business',
              premium: `₹ ${quote.quoteAmount?.toLocaleString() || '0'}`,
              status: quote.status ? 'Submitted' : 'Draft',
              created: quote.created ? new Date(quote.created).toLocaleDateString() : 'N/A',
            })).filter((quote) => !deletedIds.includes(Number(quote.id)));
    
          this.quotes = formattedQuotes;
          this.filteredQuotes = [...this.quotes];
        },
        (error) => {
          this.alertMessage = 'Failed to load quotes from backend.';
          this.alertType = 'error';
          console.error(error);
        }
      );
    }
    
    paginatedQuotes() {
      const start = (this.currentPage - 1) * this.quotesPerPage;
      const end = start + this.quotesPerPage;
      return this.filteredQuotes.slice(start, end);
    }
    
    totalPages() {
      return Array(Math.ceil(this.filteredQuotes.length / this.quotesPerPage))
      .fill(0)
      .map((x, i) => i + 1);
    }
  
    goToPage(page: number) {
      this.currentPage = page;
    }
    
    previousPage() {
      if (this.currentPage > 1) {
        this.currentPage--;
      }
    }
  
    nextPage() {
      if (this.currentPage < this.totalPages().length) {
        this.currentPage++;
      }
    }
    
    onSearch(event: Event) {
      const target = event.target as HTMLInputElement;
      this.searchQuery = target.value.toLowerCase();
      this.applyFilters();
    }
  
    onFilterStatus(event: Event) {
      const target = event.target as HTMLSelectElement;
      this.filterStatus = target.value;
      this.applyFilters();
    }
  
    onSort(event: Event) {
      const target = event.target as HTMLSelectElement;
      this.sortField = target.value;
      this.applyFilters();
    }
  
    applyFilters() {
      this.filteredQuotes = this.quotes.filter((quote) => {
        const matchesSearch =
          quote.businessName.toLowerCase().includes(this.searchQuery) ||
          quote.id.toLowerCase().includes(this.searchQuery);
        const matchesStatus = this.filterStatus
        ? quote.status === this.filterStatus
          : true;
        return matchesSearch && matchesStatus;
      });
  
      if (this.sortField) {
        this.filteredQuotes.sort((a, b) => {
          if (this.sortField === 'Date') {
            return new Date(a.created).getTime() - new Date(b.created).getTime();
          } else if (this.sortField === 'Premium') {
            return parseFloat(a.premium.replace(/[^0-9.-]+/g, '')) - parseFloat(b.premium.replace(/[^0-9.-]+/g, ''));
          }
          return 0;
        });
      }
  
      this.currentPage = 1;
    }
    
    onEdit(id: string) {
      this.router.navigate(['/quoteedit', id]); 
    }

    // onDelete(id: string) {
    //   this.quoteService.deleteQuote(Number(id)).subscribe(
    //     () => {
    //       this.quotes = this.quotes.filter((quote) => quote.id !== id);
    //       this.filteredQuotes = [...this.quotes];
    //       this.alertMessage = 'Quote deleted successfully!';
    //       this.alertType = 'success';
    //       this.applyFilters();
    //     },
    //     (error) => {
    //       this.alertMessage = 'Failed to delete the quote.';
    //       this.alertType = 'error';
    //       console.error(error);
    //     }
    //   );
    // }
    onDelete(id: string) {
      try {
        this.quotes = this.quotes.filter((quote) => Number(quote.id) !== Number(id));
        this.filteredQuotes = [...this.quotes];
        // Store deleted IDs in localStorage
        let deletedIds = JSON.parse(localStorage.getItem('deletedQuotes') || '[]');
        deletedIds.push(Number(id));
        localStorage.setItem('deletedQuotes', JSON.stringify(deletedIds));
        this.alertMessage = 'Quote removed from the list!';
        this.alertType = 'success';
        this.applyFilters();
      } catch (error) {
        this.alertMessage = 'An error occurred while removing the quote.';
        this.alertType = 'error';
        console.error(error);
      }
    }
  
    onView(id: string) {
      this.router.navigate(['/quotedetails', id]); 
    }
}
