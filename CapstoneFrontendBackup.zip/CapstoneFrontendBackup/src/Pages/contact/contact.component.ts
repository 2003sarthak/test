import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { AbstractControl, FormControl, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { EmailService } from '../../Services/Email.Service/email.service';
import { AlertComponent } from '../../shared/Components/alert/alert.component';

@Component({
  selector: 'app-contact',
  imports: [ReactiveFormsModule,CommonModule,FormsModule,AlertComponent],
  templateUrl: './contact.component.html',
  styleUrl: './contact.component.css',
  standalone:true,
})
export class ContactComponent {
  alertMessage: string | null = null;
  alertType: 'success' | 'error' | null = null;
  contacts: any[] = [];
  form: FormGroup = new FormGroup({
    name: new FormControl('', {
      validators: [Validators.minLength(4), Validators.required]
    }),
    email: new FormControl('', {
      validators: [Validators.required, this.customEmailValidator]
    }),
    phone: new FormControl('', {
      validators: [Validators.required, Validators.pattern('^[0-9]{10}$')]
    }),
    message: new FormControl('', {
      validators: [Validators.required, Validators.minLength(10), Validators.maxLength(500)]
    })
  });

  constructor(private emailService: EmailService) {}

  ngOnInit(): void {
  }

  getError(control: any): string {
    if (control.errors?.required && control.touched)
      return 'This field is required';
    else if (control.errors?.emailError && control.touched)
      return 'Please enter a valid email address';
    else return '';
  }

  customEmailValidator(control: AbstractControl) {
    const pattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
    const value = control.value;
    return !pattern.test(value) ? { emailError: true } : null;
  }

  onSave() {
    if (this.form.valid) {
      const { name, email, message } = this.form.value;

      // Send email using EmailService
      this.emailService.sendContactEmail(name, email, message);

      // Show custom alert
      this.alertMessage = `Hi ${name}, your message has been sent successfully!`;
      this.alertType = 'success';

      // Reset form after submission
      this.form.reset();
    } else {
      this.alertMessage = 'Please fill out all required fields correctly!';
      this.alertType = 'error';
    }
  }
}




