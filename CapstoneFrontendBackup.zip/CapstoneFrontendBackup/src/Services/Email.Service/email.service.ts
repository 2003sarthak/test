// import { HttpClient } from '@angular/common/http';
// import { Injectable } from '@angular/core';

// @Injectable({
//   providedIn: 'root'
// })
// export class EmailService {
//   constructor(private http: HttpClient) {}

//   sendQuoteEmail(email: string, brokerName: string, pdfBlob: Blob) {
//     const reader = new FileReader();
//     reader.readAsDataURL(pdfBlob);
//     reader.onloadend = () => {
//       const pdfBase64 = reader.result?.toString().split(',')[1]; // Get Base64 part

//       const requestBody = {
//         email,
//         brokerName,
//         pdfBase64
//       };

//       this.http.post('http://localhost:5111/api/Email/sendQuote', requestBody).subscribe({
//         next: () => console.log('Email sent successfully'),
//         error: (err) => console.error('Error sending email:', err)
//       });
//     };
//   }
// }
import { Injectable } from '@angular/core';
import emailjs from 'emailjs-com';

@Injectable({
  providedIn: 'root'
})
export class EmailService {
  private emailJsUserId = 'rRtlqngCLC7Aksepj'; 
  private emailJsServiceId = 'service_r0zpjrw'; 
  private emailJsTemplateId = 'template_k72k5ay'; 

  sendQuoteEmail(userEmail: string, brokerName: string, quoteDetails: any, pdfBlob?: Blob): void {
    const emailParams: any = {
      user_email: userEmail,
      broker_name: brokerName,
      business_name: quoteDetails.businessName,
      gst_number: quoteDetails.gstNo,
      annual_turnover: `Rs. ${quoteDetails.annualTurnover}`,
      property_value: `Rs. ${quoteDetails.propertyValue}`,
      location_type: quoteDetails.locationType,
      contact_person: quoteDetails.contactPersonName,
      phone_number: quoteDetails.contactPhoneNumber,
      email: quoteDetails.email,
      business_address: quoteDetails.businessAddress,
      year_of_operation: quoteDetails.yearOfOperation,
      number_of_employees: quoteDetails.numberOfEmployees,
      natural_calamity_coverage: quoteDetails.naturalCalamityCoverageNeeded ? 'Yes' : 'No',
      about_business: quoteDetails.aboutBusiness,
      plan_type: quoteDetails.planType,
      quote_amount: `Rs. ${quoteDetails.quoteAmount}`,
      status: quoteDetails.status ? 'Submitted' : 'Draft'
    };

    if (pdfBlob) {
      const reader = new FileReader();
      reader.readAsDataURL(pdfBlob);
      reader.onloadend = () => {
        const pdfBase64 = reader.result?.toString().split(',')[1]; // Extract the Base64 part
        emailParams.quote_pdf = pdfBase64; // Attach the PDF file

        emailjs.send(this.emailJsServiceId, this.emailJsTemplateId, emailParams, this.emailJsUserId)
          .then(() => console.log('Email sent successfully with quote details'))
          .catch((error) => console.error('Error sending email:', error));
      };
    } else {
      // Send email without PDF
      emailjs.send(this.emailJsServiceId, this.emailJsTemplateId, emailParams, this.emailJsUserId)
        .then(() => console.log('Email sent successfully with quote details (no PDF)'))
        .catch((error) => console.error('Error sending email:', error));
    }
  }
}