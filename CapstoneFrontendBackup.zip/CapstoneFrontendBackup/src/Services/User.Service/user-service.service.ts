// import { Injectable } from '@angular/core';
// import { User } from '../../shared/Models/User.Model';
// import { BehaviorSubject } from 'rxjs';
// import * as bcrypt from 'bcryptjs';

// @Injectable({
//   providedIn: 'root'
// })
// export class UserServiceService {

//   private users: User[] = [];
//   private loggedInUser: User | null = null;
//   private userLoggedInSubject = new BehaviorSubject<User | null>(null);
//   userLoggedIn$ = this.userLoggedInSubject.asObservable();

//   constructor() {
//     const storedUsers = localStorage.getItem('users');
//     if (storedUsers) {
//       this.users = JSON.parse(storedUsers);
//     }
//     const storedLoggedInUser = localStorage.getItem('loggedInUser');
//     if (storedLoggedInUser) {
//       this.loggedInUser = JSON.parse(storedLoggedInUser);
//       this.userLoggedInSubject.next(this.loggedInUser);
//     }
//   }

//   addUser(user: User): void {
//     const salt = bcrypt.genSaltSync(10);
//     user.password = bcrypt.hashSync(user.password, salt);
//     this.users.push(user);
//     localStorage.setItem('users', JSON.stringify(this.users));
//     this.setLoggedInUser(user);
//   }

//   getUser(email: string, password: string): User | undefined {
//     const user = this.users.find(user => user.email === email);
//     if (user && bcrypt.compareSync(password, user.password)) {
//       return user;
//     }
//     return undefined;
//   }

//   setLoggedInUser(user: User): void {
//     this.loggedInUser = user;
//     localStorage.setItem('loggedInUser', JSON.stringify(user));
//     this.userLoggedInSubject.next(user);
//   }

//   getLoggedInUser(): User | null {
//     return this.loggedInUser;
//   }

//   logout(): void {
//     this.loggedInUser = null;
//     localStorage.removeItem('loggedInUser');
//     this.userLoggedInSubject.next(null);
//   }

// }


import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { User } from '../../shared/Models/User.Model';
import * as bcrypt from 'bcryptjs';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class UserServiceService {

  private loggedInUser: User | null = null;
  private userLoggedInSubject = new BehaviorSubject<User | null>(null);
  userLoggedIn$ = this.userLoggedInSubject.asObservable();

  private apiBaseUrl = 'http://localhost:5111/api/UserModels'; 

  constructor(private http: HttpClient) {
    const storedLoggedInUser = localStorage.getItem('loggedInUser');
    if (storedLoggedInUser) {
      this.loggedInUser = JSON.parse(storedLoggedInUser);
      this.userLoggedInSubject.next(this.loggedInUser);
    }
  }

  addUser(user: User): Promise<User> {
    return this.http.post<User>(`${this.apiBaseUrl}/register`, user).toPromise()
      .then((newUser) => {
        if (!newUser) {
          throw new Error('User registration failed or returned invalid data.');
        }
        const salt = bcrypt.genSaltSync(10);
        newUser.password = bcrypt.hashSync(newUser.password || '', salt);
        this.setLoggedInUser(newUser);
        return newUser;
      }).catch((error) => {
        console.error('Registration error:', error);
        throw error;
      });
  }
  

  getUser(email: string, password: string): Promise<User | null> {
    return this.http.post<any>(`${this.apiBaseUrl}/login`, { email, password }).toPromise()
      .then((response) => {
        if (response && response.token) {
          localStorage.setItem('authToken',response.token);
          const userPayload=this.decodeToken(response.token);
          const user={email,...userPayload} as User;
          this.setLoggedInUser(user);
          return user;
        }
        return null;
      }).catch(() => {
        return null;
      });
  }

  decodeToken(token:string):any{
    const payload=token.split('.')[1];
    return JSON.parse(atob(payload));
  }

  setLoggedInUser(user: User): void {
    localStorage.setItem('loggedInUser', JSON.stringify(user));
    this.loggedInUser = user;
    this.userLoggedInSubject.next(user);
  }

  getLoggedInUser(): User | null {
    return this.loggedInUser;
  }

  logout(): void {
    this.loggedInUser = null;
    localStorage.removeItem('authToken')
    localStorage.removeItem('loggedInUser');
    this.userLoggedInSubject.next(null);
  }
}