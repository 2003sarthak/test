import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { QuoteCalculationDto } from '../../shared/Models/QuoteCalculationDto .Model';

@Injectable({
  providedIn: 'root'
})
export class RatingService {
  private apiBaseUrl = 'http://localhost:5111/api/Rating'; 

  constructor(private http: HttpClient) {}

  calculateQuote(quote: QuoteCalculationDto): Observable<any> {
    return this.http.post<any>(`${this.apiBaseUrl}/calculate`, quote);
  }

}
