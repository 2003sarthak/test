import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Quote } from '../../shared/Models/Quote.Model';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class QuoteService {
  private apiBaseUrl = 'http://localhost:5111/api/QuoteModels'; // Replace with your backend API's URL

  constructor(private http: HttpClient) {}

  
  private getHeaders(): HttpHeaders {
    const loggedInUser = JSON.parse(localStorage.getItem('loggedInUser') || '{}');
    const headers = new HttpHeaders()
      .set('Content-Type', 'application/json')
      .set('userEmail', loggedInUser.email || 'default@example.com')
      .set('brokerId', loggedInUser.brokerId || '0')
      .set('brokerName', loggedInUser.brokerName || 'Default Broker');
  
    // console.log('Constructed Headers:', headers);
    return headers;
  }

  getQuotes(): Observable<Quote[]> {
    return this.http.get<Quote[]>(`${this.apiBaseUrl}/list`, { headers: this.getHeaders() });
  }

  getQuoteById(id: number): Observable<Quote> {
    return this.http.get<Quote>(`${this.apiBaseUrl}/get/${id}`, { headers: this.getHeaders() });
  }

  createQuote(quote: Quote): Observable<Quote> {
    console.log(this.getHeaders())
    return this.http.post<Quote>(`${this.apiBaseUrl}/create`, quote, { headers: this.getHeaders() });
  }

  editQuote(id: number, quote: Quote): Observable<any> {
    return this.http.put(`${this.apiBaseUrl}/edit/${id}`, quote, { headers: this.getHeaders() });
  }

  deleteQuote(id: number): Observable<any> {
    return this.http.delete(`${this.apiBaseUrl}/delete/${id}`, { headers: this.getHeaders() });
  }

}




// private getHeaders(): HttpHeaders {
  //   const loggedInUser = JSON.parse(localStorage.getItem('loggedInUser') || '{}');
  //   console.log(loggedInUser);
  //   const email = loggedInUser.email || '';
  //   const brokerId = loggedInUser.brokerId || '';
  //   const brokerName = loggedInUser.brokerName || '';
  //   console.log({email,brokerId,brokerName})
  //   return new HttpHeaders({
  //     'Content-Type': 'application/json',
  //     'userEmail': email,
  //     'brokerId': brokerId,
  //     'brokerName': brokerName
  //   });
  // }