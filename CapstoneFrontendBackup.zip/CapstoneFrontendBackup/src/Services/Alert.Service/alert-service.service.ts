import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AlertServiceService {

  private alertsSubject = new BehaviorSubject<any[]>(this.getStoredAlerts());
  alerts$ = this.alertsSubject.asObservable();

  getStoredAlerts(): any[] {
    const storedAlerts = localStorage.getItem('alerts');
    return storedAlerts ? JSON.parse(storedAlerts) : [];
  }

  addAlert(newAlert: any) {
    let currentAlerts = this.getStoredAlerts();
    currentAlerts.push(newAlert);
    localStorage.setItem('alerts', JSON.stringify(currentAlerts));
    this.alertsSubject.next(currentAlerts); // Notify components dynamically
  }

  markAlertAsRead(index: number) {
    let alerts = this.getStoredAlerts();
    alerts[index].seen = true;
    localStorage.setItem('alerts', JSON.stringify(alerts));
    this.alertsSubject.next(alerts);
  }
}

