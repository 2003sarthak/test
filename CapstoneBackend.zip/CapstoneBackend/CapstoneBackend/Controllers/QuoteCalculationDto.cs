﻿using CapstoneBackend.Models;
using System.ComponentModel.DataAnnotations.Schema;

namespace CapstoneBackend.Controllers
{
    public class QuoteCalculationDto
    {
        
        public double annualTurnover { get; set; }
        
        public int propertyValue { get; set; }
        public string ownershipType { get; set; }
        
        public string businessType { get; set; }
        
        public string locationType { get; set; }
        
        public string planType { get; set; }
    }
}
