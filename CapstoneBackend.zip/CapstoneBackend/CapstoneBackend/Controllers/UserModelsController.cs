﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using CapstoneBackend.Models;
using Microsoft.AspNetCore.Cors;
using CapstoneBackend.Helpers;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.AspNetCore.Authorization;

namespace CapstoneBackend.Controllers
{
    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    [EnableCors("allowCors")]
    public class UserModelsController : ControllerBase
    {
        private readonly AppDbContext _context;

        public UserModelsController(AppDbContext context)
        {
            _context = context;
        }

        // GET: api/UserModels
        [HttpGet("list")]
        public async Task<ActionResult<IEnumerable<UserModel>>> GetUsers()
        {
            return await _context.Users.ToListAsync();
        }
        [AllowAnonymous]
        // GET: api/UserModels/5
        [HttpPost("login")]
        public async Task<ActionResult<UserModel>> GetUserModel([FromBody] LoginRequest request)
        {
            if (string.IsNullOrEmpty(request.email) || string.IsNullOrEmpty(request.password))
            {
                return BadRequest("Email and password are required");
            }

            var userModel = await _context.Users.FirstOrDefaultAsync(u => u.email == request.email && u.password == request.password);

            if (userModel == null)
            {
                return Unauthorized("Invalid EmailId or password");
            }

            var token = JwtHelper.GenerateToken(userModel, _context.GetService<IConfiguration>());

            return Ok(new { token });

        }

        // GET: api/UserModels/quotes/5
        [HttpGet("quotes/{id}")]
        public async Task<ActionResult<UserModel>> GetQuotesByUser(int id)
        {
            var userModel = await _context.Users.Include(u => u.quotes).FirstOrDefaultAsync(u => u.BrokerId == id);

            if (userModel == null)
            {
                return NotFound("User Not Found ");
            }

            return Ok(userModel.quotes.ToList());
        }

        // PUT: api/UserModels/5
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [HttpPut("edit/{id}")]
        public async Task<IActionResult> PutUserModel(int id, UserModel userModel)
        {
            if (id != userModel.BrokerId)
            {
                return BadRequest("User ID missmatch ");
            }

            _context.Entry(userModel).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!UserModelExists(id))
                {
                    return NotFound("User Not Found");
                }
                else
                {
                    throw;
                }
            }

            return Ok(new { message = "Quote Edited successfully " });
        }

        // POST: api/UserModels
        // To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
        [AllowAnonymous]
        [HttpPost("register")]
        public async Task<ActionResult<UserModel>> PostUserModel(UserModel userModel)
        {
            if (userModel == null)
            {
                return BadRequest("Invalid user Data");
            }

            var existingUser = await _context.Users.FirstOrDefaultAsync(u => u.email == userModel.email);
            if (existingUser != null)
            {
                return Conflict("A user with this email already exists. ");
            }
            _context.Users.Add(userModel);
            await _context.SaveChangesAsync();

            return CreatedAtAction("GetUserModel", new { id = userModel.BrokerId }, userModel);
        }

        // DELETE: api/UserModels/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteUserModel(int id)
        {
            var userModel = await _context.Users.FindAsync(id);
            if (userModel == null)
            {
                return NotFound("User Id Not Found ");
            }

            _context.Users.Remove(userModel);
            await _context.SaveChangesAsync();

            return Ok(new { message = "User deleted successfully " });
        }

        private bool UserModelExists(int id)
        {
            return _context.Users.Any(e => e.BrokerId == id);
        }
    }
}
