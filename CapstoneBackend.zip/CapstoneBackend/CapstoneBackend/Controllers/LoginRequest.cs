﻿namespace CapstoneBackend.Controllers
{
    public class LoginRequest
    {
        public string email { get; set; }
        public string password { get; set; }
    }
}
