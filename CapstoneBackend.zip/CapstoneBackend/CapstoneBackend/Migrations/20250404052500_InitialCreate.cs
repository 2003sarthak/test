﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace CapstoneBackend.Migrations
{
    /// <inheritdoc />
    public partial class InitialCreate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Users",
                columns: table => new
                {
                    BrokerId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    fullName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    email = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    password = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Users", x => x.BrokerId);
                });

            migrationBuilder.CreateTable(
                name: "Quotes",
                columns: table => new
                {
                    id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    businessName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    GSTNo = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    annualTurnover = table.Column<double>(type: "float", nullable: false),
                    propertyType = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    propertyValue = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ownershipType = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    businessType = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    locationType = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    securitySystem = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    previousClaims = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    securityMeasures = table.Column<bool>(type: "bit", nullable: false),
                    planType = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    quoteAmount = table.Column<double>(type: "float", nullable: false),
                    status = table.Column<bool>(type: "bit", nullable: false),
                    created = table.Column<DateTime>(type: "datetime2", nullable: false),
                    brokerId = table.Column<int>(type: "int", nullable: false),
                    brokerName = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Quotes", x => x.id);
                    table.ForeignKey(
                        name: "FK_Quotes_Users_brokerId",
                        column: x => x.brokerId,
                        principalTable: "Users",
                        principalColumn: "BrokerId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Quotes_brokerId",
                table: "Quotes",
                column: "brokerId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Quotes");

            migrationBuilder.DropTable(
                name: "Users");
        }
    }
}
