﻿using Microsoft.EntityFrameworkCore;

namespace CapstoneBackend.Models
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        public DbSet<UserModel> Users { get; set; }
        public DbSet<QuoteModel> Quotes { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<QuoteModel>()
                .HasOne(q => q.broker)
                .WithMany(u => u.quotes)
                .HasForeignKey(u => u.brokerId)
                .OnDelete(DeleteBehavior.Cascade);
        }


    }
}
