package com.example.MusicLibrary.models;

import jakarta.persistence.*;
import lombok.*;
import java.util.Date;
@Entity
@Table(name = "songs")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Songs {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String name;

    @Column(nullable = false)
    private String artist;

    private String album;
    private String musicDirector;

    @Temporal(TemporalType.DATE)
    private Date releaseDate;

    @Column(nullable = false)
    private String fileUrl; // Link to the music file (Firebase, AWS S3, etc.)
}

