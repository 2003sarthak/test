package com.example.MusicLibrary.dto;
import lombok.Data;

@Data
public class SongDTO {
    private Long id;
    private String name;
    private String artist;
    private String album;
    private String musicDirector;
    private String releaseDate;
}
