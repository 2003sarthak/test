package com.example.MusicLibrary.service;
import com.example.MusicLibrary.models.Playlist;
import com.example.MusicLibrary.models.User;
import com.example.MusicLibrary.repository.PlaylistRepository;
import com.example.MusicLibrary.service.PlaylistService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class PlaylistServiceImpl implements PlaylistService {

    @Autowired
    private PlaylistRepository playlistRepository;

    @Override
    public Playlist createPlaylist(Playlist playlist) {
        return playlistRepository.save(playlist);
    }

    @Override
    public List<Playlist> getUserPlaylists(User user) {
        return playlistRepository.findByUser(user);
    }

    @Override
    public void deletePlaylist(Long id) {
        playlistRepository.deleteById(id);
    }
}
