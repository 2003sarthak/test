package com.example.MusicLibrary.dto;
import lombok.Data;
import java.util.List;

@Data
public class PlaylistDTO {
    private Long id;
    private String name;
    private Long userId;
    private List<Long> songIds;
}
