package com.example.MusicLibrary.models;

public enum Role {
    ADMIN, USER
}
