package com.example.MusicLibrary.service;

import com.example.MusicLibrary.models.Songs;

import java.util.List;

public interface SongService {
    Songs addSong(Songs song);
    List<Songs> getAllSongs();
    List<Songs> searchSongs(String keyword);
    void deleteSong(Long id);
}
