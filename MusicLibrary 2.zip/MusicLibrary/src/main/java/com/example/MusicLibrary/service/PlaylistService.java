package com.example.MusicLibrary.service;
import com.example.MusicLibrary.models.Playlist;
import com.example.MusicLibrary.models.User;
import java.util.List;

public interface PlaylistService {
    Playlist createPlaylist(Playlist playlist);
    List<Playlist> getUserPlaylists(User user);
    void deletePlaylist(Long id);
}
