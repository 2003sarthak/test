package com.example.MusicLibrary.config;

public class CorsConfig {
}
