package com.example.MusicLibrary.service;


import com.example.MusicLibrary.models.Songs;

import com.example.MusicLibrary.repository.SongRepository;
import com.example.MusicLibrary.service.SongService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
public class SongServiceImpl implements SongService {

    @Autowired
    private SongRepository songRepository;

    @Override
    public Songs addSong(Songs song) {
        return songRepository.save(song);
    }

    @Override
    public List<Songs> getAllSongs() {
        return songRepository.findAll();
    }

    @Override
    public List<Songs> searchSongs(String keyword) {
        return songRepository.findByArtistContainingIgnoreCase(keyword);
    }

    @Override
    public void deleteSong(Long id) {
        songRepository.deleteById(id);
    }
}
