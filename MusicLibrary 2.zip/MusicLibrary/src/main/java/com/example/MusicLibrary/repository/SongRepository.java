package com.example.MusicLibrary.repository;
import com.example.MusicLibrary.models.Songs;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface SongRepository extends JpaRepository<Songs, Long> {
    List<Songs> findByArtistContainingIgnoreCase(String artist);
    List<Songs> findByAlbumContainingIgnoreCase(String album);
    List<Songs> findByMusicDirectorContainingIgnoreCase(String musicDirector);
}
